package net

import (
    "fmt"
    "net"
    "net/http"
    "strings"
)

const (
    networkSpliter = "@"
)

func ParseNetwork(str string) (network, addr string, err error) {
    if idx := strings.Index(str, networkSpliter); idx == -1 {
        err = fmt.Errorf("addr: \"%s\" error, must be network@tcp:port or network@unixsocket", str)
        return
    } else {
        network = str[:idx]
        addr = str[idx+1:]
        return
    }
}

func GetIP(r *http.Request) string {
    ips := GetProxy(r)
    if len(ips) > 0 && ips[0] != "" {
        rip, _, err := net.SplitHostPort(ips[0])
        if err != nil {
            rip = ips[0]
        }
        return rip
    }
    if ip, _, err := net.SplitHostPort(r.RemoteAddr); err == nil {
        return ip
    }
    return r.RemoteAddr
}

func GetProxy(r *http.Request) []string {
    if ips := r.Header.Get("X-Forwarded-For"); ips != "" {
        return strings.Split(ips, ",")
    }
    return []string{}
}
