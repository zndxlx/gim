package proto

type NoArg struct {
}

type NoReply struct {
}

type PushMsgArg struct {
    Key string
    P   Proto
}

type PushMsgsArg struct {
    Key    string
    PMArgs []*PushMsgArg
}

type PushMsgsReply struct {
    Index int32
}

type MPushMsgArg struct {
    Keys []string
    P    Proto
}

type MPushMsgReply struct {
    Index int32
}

type MPushMsgsArg struct {
    PMArgs []*PushMsgArg
}

type MPushMsgsReply struct {
    Index int32
}

type BoardcastArg struct {
    P Proto
}

type BoardcastRoomArg struct {
    RoomId int32
    P      Proto
}

type RoomsReply struct {
    RoomIds map[int32]struct{}
}

type NotifyActiveArg struct {
    Keys []string
}

type NotifyMsgArg struct {
    Keys  []string
    MsgID int64
}

//和客户端消息的定义

type CSyncMsgReq struct {
    MsgID string `json:"msgID"`
}

type CMsgNotify struct {
    MsgID string `json:"msgID"`
}

type Message struct {
    MsgID    string `json:"msgID"`
    SendTime string `json:"sendTime"`
    MsgBody  string `json:"msgBody"`
}

type CSyncMsgRsp struct {
    Ret  int32     `json:ret` //200 成功  400 请求错误  500 服务器错误
    Msgs []Message `json:"msgs"`
}

type CAckMsgReq struct {
    MsgIDs []string `json:"msgIDs"`
}
