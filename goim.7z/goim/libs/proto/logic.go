package proto

type ConnArg struct {
    Token    string
    Server   int32
    ClientIp string
}

type ConnReply struct {
    Key          string
    RoomId       int32
    LastMsgID    int64
    LastAckMsgID int64
}

type DisconnArg struct {
    Key    string
    RoomId int32
}

type DisconnReply struct {
    Has bool
}

type SyncMsgReq struct {
    Key   string
    Appid int32
    MsgID string
}

type SyncMsgRsp struct {
    Msgs []Message
}

type AckMsgReq struct {
    Key    string
    Appid  int32
    MsgIDs []string
}
type AckMsgRsp struct {
}
