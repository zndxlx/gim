package time

const (
    Debug = false
)
