package main

import (
    "bufio"
    "encoding/binary"
    "net"
    "time"

    "encoding/json"
    "flag"
    "fmt"
    log "github.com/thinkboy/log4go"
    "sort"
)

const (
    rawHeaderLen = uint16(16)
    heart        = 60 * time.Second //s
)

type Proto struct {
    PackLen   int32  // package length
    HeaderLen int16  // header length
    Ver       int16  // protocol version
    Operation int32  // operation for request
    SeqId     int32  // sequence number chosen by client
    Body      []byte // body
}

const (
    // handshake
    OP_HANDSHAKE       = int32(0)
    OP_HANDSHAKE_REPLY = int32(1)
    // heartbeat
    OP_HEARTBEAT       = int32(2)
    OP_HEARTBEAT_REPLY = int32(3)
    // send text messgae
    OP_SEND_SMS       = int32(4)
    OP_SEND_SMS_REPLY = int32(5)
    // kick user
    OP_DISCONNECT_REPLY = int32(6)
    // auth user
    OP_AUTH       = int32(7)
    OP_AUTH_REPLY = int32(8)
    // handshake with sid
    OP_HANDSHAKE_SID       = int32(9)
    OP_HANDSHAKE_SID_REPLY = int32(10)
    // raw message
    OP_RAW = int32(11)
    // room
    OP_ROOM_READY = int32(12)
    // proto
    OP_PROTO_READY  = int32(13)
    OP_PROTO_FINISH = int32(14)
    // update capbility
    OP_UPDATE       = int32(15)
    OP_UPDATE_REPLY = int32(16)

    //客户端同步消息
    OP_SYNC_MSG       = int32(17)
    OP_SYNC_MSG_REPLY = int32(18)
    OP_ACK_MSG        = int32(19)
    OP_MSG_NOTIFY     = int32(20)
    // for test
    OP_TEST       = int32(254)
    OP_TEST_REPLY = int32(255)
)

var (
    gUid      int64
    gComet    string
    gCap      string
    gAppid    string
    gLastMsg  string //记录登陆时候服务器返回的
    gLastAck  string
    gLastRecv string
)

type CSyncMsgReq struct {
    MsgID string `json:"msgID"`
}

type Message struct {
    MsgID    string `json:"msgID"`
    SendTime string `json:"sendTime"`
    MsgBody  string `json:"msgBody"`
}

type CSyncMsgRsp struct {
    Ret  int32     `json:ret` //200 成功  400 请求错误  500 服务器错误
    Msgs []Message `json:"msgs"`
}

type CAckMsgReq struct {
    MsgIDs []string `json:"msgIDs"`
}

type CMsgNotify struct {
    MsgID string `json:"msgID"`
}

type CAuthRsp struct {
    LastAck string `json:"lastAck"`
    LastMsg string `json:"lastMsg"`
}

func init() {
    flag.Int64Var(&gUid, "uid", 2000, "uid")
    flag.StringVar(&gComet, "comet", "127.0.0.1:8080", "comet server ip")
    flag.StringVar(&gCap, "cap", `{"ver":"2.0"}`, "client cap")
    flag.StringVar(&gAppid, "appid", "14", "client appid")
}

func main() {
    flag.Parse()
    defer log.Close()
    conn, err := net.Dial("tcp", gComet)
    if err != nil {
        log.Error("net.Dial(\"%s\") error(%v)", gComet, err)
        return
    }
    seqId := int32(0)
    wr := bufio.NewWriter(conn)
    rd := bufio.NewReader(conn)
    proto := new(Proto)
    proto.Ver = 1
    // auth
    // test handshake timeout
    // time.Sleep(time.Second * 31)
    proto.Operation = OP_AUTH
    proto.SeqId = seqId
    proto.Body = []byte(fmt.Sprintf("%d;%s;%s", gUid, gCap, gAppid))
    if err = tcpWriteProto(wr, proto); err != nil {
        log.Error("tcpWriteProto() error(%v)", err)
        return
    }
    if err = tcpReadProto(rd, proto); err != nil {
        log.Error("tcpReadProto() error(%v)", err)
        return
    }
    log.Debug("auth ok, body: %v", string(proto.Body))

    var authRsp CAuthRsp
    json.Unmarshal(proto.Body, &authRsp)
    gLastMsg = authRsp.LastMsg
    gLastAck = authRsp.LastAck
    gLastRecv = authRsp.LastAck
    if gLastAck < gLastMsg {
        syncMsg(wr, gLastAck)
    }

    seqId++
    go func() {
        proto1 := new(Proto)
        for {
            // heartbeat
            proto1.Operation = OP_HEARTBEAT
            proto1.SeqId = seqId
            proto1.Body = nil
            if err = tcpWriteProto(wr, proto1); err != nil {
                log.Error("tcpWriteProto() error(%v)", err)
                return
            }
            time.Sleep(time.Second * 31)
            seqId++
        }
    }()
    // reader
    for {
        if err = tcpReadProto(rd, proto); err != nil {
            log.Error("tcpReadProto() error(%v)", err)
            return
        }
        if proto.Operation == OP_HEARTBEAT_REPLY {
            log.Debug("receive heartbeat")
        } else if proto.Operation == OP_SYNC_MSG_REPLY {
            log.Debug("receive OP_SYNC_MSG_REPLY body: %s", string(proto.Body))
            var rsp CSyncMsgRsp
            json.Unmarshal(proto.Body, &rsp)
            idList := make([]string, len(rsp.Msgs))
            for index, msg := range rsp.Msgs {
                idList[index] = msg.MsgID
            }
            if len(idList) > 0 {
                ackMsg(wr, idList)
                sort.Strings(idList)
                gLastRecv = idList[len(idList)-1]
            }

        } else if proto.Operation == OP_MSG_NOTIFY {
            log.Debug("receive OP_MSG_NOTIFY body: %s", string(proto.Body))
            var notify CMsgNotify
            json.Unmarshal(proto.Body, &notify)
            syncMsg(wr, gLastRecv)
        } else {
            log.Debug("receive  body: %s", string(proto.Body))
        }
    }
}

func syncMsg(wr *bufio.Writer, msgid string) {
    proto1 := new(Proto)
    proto1.Operation = OP_SYNC_MSG
    proto1.SeqId = 11
    proto1.Body = []byte(fmt.Sprintf(`{"msgID":"%s"}`, msgid))
    if err := tcpWriteProto(wr, proto1); err != nil {
        log.Error("tcpWriteProto() error(%v)", err)
        return
    }
}

func ackMsg(wr *bufio.Writer, msgids []string) {
    proto1 := new(Proto)
    var req CAckMsgReq
    req.MsgIDs = msgids

    b, err := json.Marshal(req)
    if err != nil {
        log.Error("json.Marshal() error(%v)", err)
        return
    }

    proto1.Operation = OP_ACK_MSG
    proto1.SeqId = 11
    proto1.Body = b
    if err = tcpWriteProto(wr, proto1); err != nil {
        log.Error("tcpWriteProto() error(%v)", err)
        return
    }
}

func tcpWriteProto(wr *bufio.Writer, proto *Proto) (err error) {
    // write
    if err = binary.Write(wr, binary.BigEndian, uint32(rawHeaderLen)+uint32(len(proto.Body))); err != nil {
        return
    }
    if err = binary.Write(wr, binary.BigEndian, rawHeaderLen); err != nil {
        return
    }
    if err = binary.Write(wr, binary.BigEndian, proto.Ver); err != nil {
        return
    }
    if err = binary.Write(wr, binary.BigEndian, proto.Operation); err != nil {
        return
    }
    if err = binary.Write(wr, binary.BigEndian, proto.SeqId); err != nil {
        return
    }
    if proto.Body != nil {
        //log.Debug("cipher body: %v", proto.Body)
        if err = binary.Write(wr, binary.BigEndian, proto.Body); err != nil {
            return
        }
    }
    err = wr.Flush()

    log.Debug("write proto, ver:%d,op:%d,seq:%d,body:%v",
        proto.Ver, proto.Operation, proto.SeqId, string(proto.Body))
    return
}

func tcpReadProto(rd *bufio.Reader, proto *Proto) (err error) {
    var (
        packLen   int32
        headerLen int16
    )
    // read
    if err = binary.Read(rd, binary.BigEndian, &packLen); err != nil {
        return
    }
    //log.Debug("packLen: %d", packLen)
    if err = binary.Read(rd, binary.BigEndian, &headerLen); err != nil {
        return
    }
    //log.Debug("headerLen: %d", headerLen)
    if err = binary.Read(rd, binary.BigEndian, &proto.Ver); err != nil {
        return
    }
    //log.Debug("ver: %d", proto.Ver)
    if err = binary.Read(rd, binary.BigEndian, &proto.Operation); err != nil {
        return
    }
    //log.Debug("operation: %d", proto.Operation)
    if err = binary.Read(rd, binary.BigEndian, &proto.SeqId); err != nil {
        return
    }
    //log.Debug("seqId: %d", proto.SeqId)
    var (
        n       = int(0)
        t       = int(0)
        bodyLen = int(packLen - int32(headerLen))
    )
    //log.Debug("read body len: %d", bodyLen)
    if bodyLen > 0 {
        proto.Body = make([]byte, bodyLen)
        for {
            if t, err = rd.Read(proto.Body[n:]); err != nil {
                return
            }
            if n += t; n == bodyLen {
                break
            } else if n < bodyLen {
            } else {
            }
        }
    } else {
        proto.Body = nil
    }
    return
}
