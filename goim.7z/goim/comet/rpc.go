package main

import (
    inet "goim/libs/net"
    "goim/libs/proto"
    "net"
    "net/rpc"

    "fmt"
    log "github.com/thinkboy/log4go"
    "goim/libs/define"
)

func InitRPCPush(addrs []string) (err error) {
    var (
        bind          string
        network, addr string
        c             = &PushRPC{}
    )
    rpc.Register(c)
    for _, bind = range addrs {
        if network, addr, err = inet.ParseNetwork(bind); err != nil {
            log.Error("inet.ParseNetwork() error(%v)", err)
            return
        }
        go rpcListen(network, addr)
    }
    return
}

func rpcListen(network, addr string) {
    l, err := net.Listen(network, addr)
    if err != nil {
        log.Error("net.Listen(\"%s\", \"%s\") error(%v)", network, addr, err)
        panic(err)
    }
    // if process exit, then close the rpc addr
    defer func() {
        log.Info("listen rpc: \"%s\" close", addr)
        if err := l.Close(); err != nil {
            log.Error("listener.Close() error(%v)", err)
        }
    }()
    rpc.Accept(l)
}

// Push RPC
type PushRPC struct {
}

func (this *PushRPC) Ping(arg *proto.NoArg, reply *proto.NoReply) error {
    return nil
}

// Push push a message to a specified sub key
func (this *PushRPC) PushMsg(arg *proto.PushMsgArg, reply *proto.NoReply) (err error) {
    if arg == nil {
        err = ErrPushMsgArg
        return
    }
    log.Debug("PushMsg Key %v", arg.Key)
    if DefaultWhitelist.Contains(arg.Key) {
        DefaultWhitelist.Log.Printf("PushMsg Key %v\n", arg.Key)
    }

    SendMsg(arg.Key, &arg.P)

    return
}

// Push push a message to specified sub keys
func (this *PushRPC) MPushMsg(arg *proto.MPushMsgArg, reply *proto.MPushMsgReply) (err error) {
    var (
        key string
        n   int
    )
    log.Debug("MPushMsg Keys %v", arg.Keys)

    reply.Index = -1
    if arg == nil {
        err = ErrMPushMsgArg
        return
    }
    for n, key = range arg.Keys {
        if DefaultWhitelist.Contains(key) {
            DefaultWhitelist.Log.Printf("MPushMsg Key %v\n", key)
        }
        SendMsg(key, &arg.P)
        reply.Index = int32(n)
    }
    return
}

// MPushMsgs push msgs to multiple user.
func (this *PushRPC) MPushMsgs(arg *proto.MPushMsgsArg, reply *proto.MPushMsgsReply) (err error) {
    var (
        n     int32
        PMArg *proto.PushMsgArg
    )

    reply.Index = -1
    if arg == nil {
        err = ErrMPushMsgsArg
        return
    }
    for _, PMArg = range arg.PMArgs {

        log.Debug("MPushMsgs Key %v", PMArg.Key)

        if err = SendMsg(PMArg.Key, &PMArg.P); err != nil {
            return
        }
        n++
        reply.Index = n
    }
    return
}

// Broadcast broadcast msg to all user.
func (this *PushRPC) Broadcast(arg *proto.BoardcastArg, reply *proto.NoReply) (err error) {
    var bucket *Bucket
    log.Debug("Broadcast %v", arg)
    for _, bucket = range DefaultServer.Buckets {
        go bucket.Broadcast(&arg.P)
    }
    return
}

// Broadcast broadcast msg to specified room.
func (this *PushRPC) BroadcastRoom(arg *proto.BoardcastRoomArg, reply *proto.NoReply) (err error) {
    var bucket *Bucket
    for _, bucket = range DefaultServer.Buckets {
        bucket.BroadcastRoom(arg)
    }
    return
}

func (this *PushRPC) Rooms(arg *proto.NoArg, reply *proto.RoomsReply) (err error) {
    var (
        roomId  int32
        bucket  *Bucket
        roomIds = make(map[int32]struct{})
    )
    for _, bucket = range DefaultServer.Buckets {
        for roomId, _ = range bucket.Rooms() {
            roomIds[roomId] = struct{}{}
        }
    }
    reply.RoomIds = roomIds
    return
}

func (this *PushRPC) NotifyActive(arg *proto.NotifyActiveArg, reply *proto.NoReply) (err error) {
    var (
        bucket  *Bucket
        channel *Channel
    )
    log.Debug("NotifyActiveArg %v", arg)

    for _, key := range arg.Keys {
        if DefaultWhitelist.Contains(key) {
            DefaultWhitelist.Log.Printf("NotifyActive Key %v\n", key)
        }
        bucket = DefaultServer.Bucket(key)
        if channel = bucket.Channel(key); channel != nil {
            if channel.DHeart {
                channel.UpdateLastActive()
            }
        }
    }

    return nil
}

func (this *PushRPC) NotifyMsg(arg *proto.NotifyMsgArg, reply *proto.NoReply) (err error) {
    var (
        bucket  *Bucket
        channel *Channel
    )

    if arg == nil {
        err = ErrNotifyMsgArg
        return
    }

    log.Info("NotifyMsg %v", arg)
    p := &proto.Proto{}
    p.Operation = define.OP_MSG_NOTIFY
    p.Body = []byte(fmt.Sprintf(`{"msgID":"%v"}`, arg.MsgID))
    for _, key := range arg.Keys {
        bucket = DefaultServer.Bucket(key)
        if channel = bucket.Channel(key); channel != nil {
            SendMsg(key, p)
        }
    }

    return nil
}
