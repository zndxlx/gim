package main

import (
    inet "goim/libs/net"
    "goim/libs/net/xrpc"
    "goim/libs/proto"
    // "time"

    log "github.com/thinkboy/log4go"
)

var (
    logicRpcClient *xrpc.Clients
    logicRpcQuit   = make(chan struct{}, 1)

    logicService           = "RPC"
    logicServicePing       = "RPC.Ping"
    logicServiceConnect    = "RPC.Connect"
    logicServiceUpdate     = "RPC.Update"
    logicServiceDisconnect = "RPC.Disconnect"
    logicServiceSyncMsg    = "RPC.SyncMsg"
    logicServiceAckMsg     = "RPC.AckMsg"
)

func InitLogicRpc(addrs []string) (err error) {
    var (
        bind          string
        network, addr string
        rpcOptions    []xrpc.ClientOptions
    )
    for _, bind = range addrs {
        if network, addr, err = inet.ParseNetwork(bind); err != nil {
            log.Error("inet.ParseNetwork() error(%v)", err)
            return
        }
        options := xrpc.ClientOptions{
            Proto: network,
            Addr:  addr,
        }
        rpcOptions = append(rpcOptions, options)
    }
    // rpc clients
    logicRpcClient = xrpc.Dials(rpcOptions)
    // ping & reconnect
    logicRpcClient.Ping(logicServicePing)
    log.Info("init logic rpc: %v", rpcOptions)
    return
}

func connect(p *proto.Proto, clientAddr string) (key string, rid int32, lastMsgID int64, lastAckMsgID int64, err error) {
    var (
        arg   = proto.ConnArg{Token: string(p.Body), Server: Conf.ServerId, ClientIp: clientAddr}
        reply = proto.ConnReply{}
    )
    if err = logicRpcClient.Call(logicServiceConnect, &arg, &reply); err != nil {
        log.Error("c.Call(\"%s\", \"%v\", &ret) error(%v)", logicServiceConnect, arg, err)
        return
    }
    key = reply.Key
    rid = reply.RoomId
    lastMsgID = reply.LastMsgID
    lastAckMsgID = reply.LastAckMsgID
    return
}

func update(p *proto.Proto, clientAddr string) (err error) {
    var (
        arg   = proto.ConnArg{Token: string(p.Body), Server: Conf.ServerId, ClientIp: clientAddr}
        reply = proto.ConnReply{}
    )
    if err = logicRpcClient.Call(logicServiceUpdate, &arg, &reply); err != nil {
        log.Error("c.Call(\"%s\", \"%v\", &ret) error(%v)", logicServiceUpdate, arg, err)
        return
    }
    return
}

func disconnect(key string, roomId int32) (has bool, err error) {
    var (
        arg   = proto.DisconnArg{Key: key, RoomId: roomId}
        reply = proto.DisconnReply{}
    )
    if err = logicRpcClient.Call(logicServiceDisconnect, &arg, &reply); err != nil {
        log.Error("c.Call(\"%s\", \"%v\", &ret) error(%v)", logicServiceConnect, arg, err)
        return
    }
    has = reply.Has
    return
}

func syncMsg(key string, appid int32, msgid string) (msgs []proto.Message, err error) {
    var (
        arg   = proto.SyncMsgReq{Key: key, Appid: appid, MsgID: msgid}
        reply = proto.SyncMsgRsp{}
    )
    if err = logicRpcClient.Call(logicServiceSyncMsg, &arg, &reply); err != nil {
        log.Error("c.Call(\"%s\", \"%v\", &ret) error(%v)", logicServiceSyncMsg, arg, err)
        return
    }

    msgs = reply.Msgs
    return
}

func ackMsg(key string, appid int32, msgIDs []string) (err error) {
    var (
        arg   = proto.AckMsgReq{Key: key, Appid: appid, MsgIDs: msgIDs}
        reply = proto.AckMsgRsp{}
    )
    if err = logicRpcClient.Call(logicServiceAckMsg, &arg, &reply); err != nil {
        log.Error("c.Call(\"%s\", \"%v\", &ret) error(%v)", logicServiceAckMsg, arg, err)
        return
    }
    return
}
