package main

import (
    "bytes"
    "os/exec"
    "runtime"
    "strconv"
    "strings"
)

type CPUInfo struct {
    Pid     int
    CPU     int
    CPUUsed float64
}

type MemoryInfo struct {
    Memory     int64
    MemoryUsed int64
}

func CollectCPUInfo() (cpuInfo CPUInfo) {
    cmd := exec.Command("ps", "aux")
    var out bytes.Buffer
    cmd.Stdout = &out
    err := cmd.Run()
    if err != nil {
        return
    }
    //	cpuInfo = new(CPUInfo)
    for {
        line, err := out.ReadString('\n')
        if err != nil {
            break
        }
        if strings.Contains(line, "comet.conf") {
            tokens := strings.Split(line, " ")
            ft := make([]string, 0)
            for _, t := range tokens {
                if t != "" && t != "\t" {
                    ft = append(ft, t)
                }
            }
            cometPid, err := strconv.Atoi(ft[1])
            if err != nil {
                continue
            }
            cpu, err := strconv.ParseFloat(ft[2], 64)
            if err != nil {
                break
            }
            cpuInfo.Pid = cometPid
            cpuInfo.CPUUsed = cpu
            cpuInfo.CPU = runtime.NumCPU()
            break
        }
    }
    return cpuInfo
}

func CollectMemoryInfo() (memoryInfo MemoryInfo) {
    cmd := exec.Command("free", "")
    var out bytes.Buffer
    cmd.Stdout = &out
    err := cmd.Run()
    if err != nil {
        return
    }
    //	memoryInfo = new(MemoryInfo)
    for {
        line, err := out.ReadString('\n')
        if err != nil {
            break
        }
        if strings.Contains(line, "Mem") {
            tokens := strings.Split(line, " ")
            ft := make([]string, 0)
            for _, t := range tokens {
                if t != "" && t != "\t" {
                    ft = append(ft, t)
                }
            }
            memoryInfo.Memory, err = strconv.ParseInt(ft[1], 10, 64)
            if err != nil {
                continue
            }
            memoryInfo.MemoryUsed, err = strconv.ParseInt(ft[2], 10, 64)
            if err != nil {
                continue
            }
            break
        }
    }
    return memoryInfo
}
