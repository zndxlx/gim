package main

import (
    log "github.com/thinkboy/log4go"
    "strconv"
    "strings"
)

const (
    DefaultHeartInterval = 60
)

//[start, end]时间段内活跃,心跳时间设置为Interval
type heartRule struct {
    Start    int64
    End      int64
    Interval int64
}

type heartRules struct {
    Rules []heartRule
}

var (
    HeartRules = &heartRules{}
)

func (p *heartRules) Init(rulesCfg []string) {
    for _, ruleCfg := range rulesCfg {
        ruleInfo := strings.Split(ruleCfg, ":")
        if len(ruleInfo) != 3 {
            log.Error("heart rule format error [ruleCfg:%s]", ruleCfg)
            panic("heart rule format error")
        }
        var rule heartRule
        var err error
        if rule.Start, err = strconv.ParseInt(ruleInfo[0], 10, 64); err != nil {
            panic(err)
        }
        if rule.End, err = strconv.ParseInt(ruleInfo[1], 10, 64); err != nil {
            panic(err)
        }
        if rule.Interval, err = strconv.ParseInt(ruleInfo[2], 10, 64); err != nil {
            panic(err)
        }
        p.Rules = append(p.Rules, rule)
    }
    log.Info("heartRules=%+v", *p)
}

func (p *heartRules) GetHeartInterval(active int64) int64 {
    for _, rule := range p.Rules {
        if active >= rule.Start && (rule.End == 0 || active <= rule.End) {
            log.Debug("active=%d, Start=%d, End=%d, Interval=%d", active,
                rule.Start, rule.End, rule.Interval)
            return rule.Interval
        }
    }
    return DefaultHeartInterval
}
