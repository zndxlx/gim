package main

import (
    "encoding/json"
    "errors"
    "fmt"
    "github.com/gorilla/websocket"
    log "github.com/thinkboy/log4go"
    "goim/libs/bufio"
    "goim/libs/bytes"
    "goim/libs/define"
    "goim/libs/proto"
    "net"
    "sync"
    "time"
)

// Channel used by message pusher send msg to write goroutine.
type Channel struct {
    RoomId            int32
    Reader            bufio.Reader
    Key               string
    Conn              *net.TCPConn
    WebConn           *websocket.Conn
    Next              *Channel
    Prev              *Channel
    BWebConn          bool
    White             bool
    DHeart            bool         //是否支持动态心跳
    LastActive        int64        //最后active的unix时间,单位秒
    LastHeartInterval int64        //上次心跳时间间隔，用于判断是否需要通知客户端心跳间隔发生改变
    Lock              sync.RWMutex // LastActive,LastHeartInterval 需要加锁
}

func NewChannel(rid int32, conn *net.TCPConn) *Channel {
    c := new(Channel)
    c.RoomId = rid
    c.Conn = conn
    c.LastActive = 0
    c.DHeart = false
    return c
}

func NewWebChannel(rid int32, conn *websocket.Conn) *Channel {
    c := new(Channel)
    c.RoomId = rid
    c.WebConn = conn
    c.LastActive = 0
    c.DHeart = false
    c.BWebConn = true
    return c
}

func (c *Channel) IsWebChannel() bool {
    return c.BWebConn
}

func (c *Channel) WriteProto(p *proto.Proto) (err error) {
    if c.IsWebChannel() {
        var pSend *proto.Proto
        if p.Operation == define.OP_SEND_SMS_REPLY {
            pSend = p.Copy()
            data := map[string]string{"data": string(pSend.Body)}
            body, tmpErr := json.Marshal(data)
            if tmpErr != nil {
                log.Error("%v, write error:%v, %v\n", c.Key, tmpErr, pSend.String())
                return tmpErr
            } else {
                pSend.Body = []byte(body)
            }
        } else {
            pSend = p
        }

        c.Lock.Lock()
        if c.WebConn == nil {
            log.Info("key=%v c.WebConn is closed", c.Key)
            err = errors.New("WebConn is closed")
        } else {
            err = pSend.WriteWebsocket(c.WebConn)
        }
        c.Lock.Unlock()
        if err != nil {
            log.Error("%v, write error:%v, %v\n", c.Key, err, p.String())
        } else {
            if p.Operation == define.OP_HEARTBEAT_REPLY {
                log.Debug("%v, write heart:%v", c.Key, p.String())
            } else {
                log.Info("%v, write:%v", c.Key, p.String())
            }
        }

        return
    } else {
        return c.WriteTCP(p)
    }
}

// Push server push message.
func (c *Channel) WriteTCP(p *proto.Proto) (err error) {
    if p.Operation == define.OP_RAW {
        _, err = c.Conn.Write(p.Body)
        if err != nil {
            log.Error("%v, write error:%v, %v\n", c.Key, err, string(p.Body[16:]))
            if c.White {
                DefaultWhitelist.Log.Printf("WriteTCP key %v, write error:%v, %v\n",
                    c.Key, err, string(p.Body[16:]))
            }
        } else {
            log.Debug("%v, write:%v", c.Key, string(p.Body[16:]))
            if c.White {
                DefaultWhitelist.Log.Printf("WriteTCP key %v, write:%v", c.Key,
                    string(p.Body[16:]))
            }
        }
    } else {
        w_buf := bytes.NewWriterSize(int(proto.MaxPackSize))
        p.WriteTo(w_buf)
        _, err = c.Conn.Write(w_buf.Buffer())

        if err != nil {
            if p.Operation == define.OP_SEND_SMS_REPLY {
                PushMsgCount.WithLabelValues("err").Inc()
            }

            log.Error("%v, write error:%v, %v\n", c.Key, err, p.String())
            if c.White {
                DefaultWhitelist.Log.Printf("WriteTCP key %v, write error:%v, %v \n",
                    c.Key, err, p.String())
            }
        } else {
            if p.Operation == define.OP_SEND_SMS_REPLY {
                log.Info("%v, write:%v", c.Key, p.String())
                PushMsgCount.WithLabelValues("ok").Inc()
                if c.DHeart {
                    c.UpdateLastActive()
                }
            } else {
                log.Debug("%v, write:%v", c.Key, p.String())
            }

            if c.White {
                DefaultWhitelist.Log.Printf("WriteTCP key %v, write:%v \n",
                    c.Key, p.String())
            }
        }
    }

    return
}

var heartbeat_buf = []byte{0x00, 0x00, 0x00, 0x10, 0x00, 0x10, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00}

func (c *Channel) SendHeartBeat() (err error) {
    log.Debug("key %s send heart", c.Key)
    if c.Conn == nil {
        log.Error("%v, tcpconn closed\n", c.Key)
        return
    }
    n, err := c.Conn.Write(heartbeat_buf)
    if err != nil {
        log.Error("%v, write heartbeat failed, n=%d, error:%v\n", c.Key, n, err)
        if c.White {
            DefaultWhitelist.Log.Printf("%v, write heartbeat failed, n=%d, error:%v\n",
                c.Key, n, err)
        }
    }
    return
}

func (c *Channel) SendHeartWithInterval(heart int64) (err error) {
    if c.Conn == nil {
        log.Error("%v, tcpconn closed\n", c.Key)
        return
    }
    log.Debug("key %s send heart, heartTime=%d", c.Key, heart)
    if c.White {
        DefaultWhitelist.Log.Printf("key %s send heart req, heartTime=%d", c.Key, heart)
    }
    body := fmt.Sprintf(`{"h":%d}`, heart)
    p := &proto.Proto{Ver: 0, Operation: define.OP_HEARTBEAT_REPLY, Body: []byte(body)}

    w_buf := bytes.NewWriterSize(int(proto.MaxPackSize))
    p.WriteTo(w_buf)
    _, err = c.Conn.Write(w_buf.Buffer())
    if err != nil {
        log.Error("%v, write heartbeat failed,  error:%v\n", c.Key, err)
        if c.White {
            DefaultWhitelist.Log.Printf("%v, write heartbeat failed, error:%v\n",
                c.Key, err)
        }
    }
    return
}

// Close close the channel.
func (c *Channel) Close() {
    if c.Conn != nil {
        c.Conn.Close()
        c.Conn = nil
    }
    if c.WebConn != nil {
        c.Lock.Lock()
        c.WebConn.Close()
        c.WebConn = nil
        c.Lock.Unlock()
    }
}

func (c *Channel) UpdateLastActive() {
    c.Lock.Lock()
    c.LastActive = time.Now().Unix()
    heartInterval := HeartRules.GetHeartInterval(0)
    if c.LastHeartInterval != heartInterval { //心跳时间间隔改变需要通知客户端
        if err := c.SendHeartWithInterval(heartInterval); err == nil {
            c.LastHeartInterval = heartInterval
        }
    }
    c.Lock.Unlock()
}

func (c *Channel) UpdateLastHeartInterval(interval int64) {
    c.Lock.Lock()
    if c.LastHeartInterval != interval {
        c.LastHeartInterval = interval
    }
    c.Lock.Unlock()
}

func (c *Channel) GetHeartInterval() (interval int64) {
    if c.DHeart == false {
        return DefaultHeartInterval
    }

    c.Lock.RLock()
    lastActive := c.LastActive
    c.Lock.RUnlock()

    timeDiff := time.Now().Unix() - lastActive

    log.Debug("Now:%v, timeDiff:%v, lastActive:%v", time.Now().Unix(), timeDiff, lastActive)

    if timeDiff < 0 {
        return DefaultHeartInterval
    }

    interval = HeartRules.GetHeartInterval(timeDiff)
    return
}
