package main

import (
    "encoding/json"
    inet "goim/libs/net"
    "net"
    "net/http"
    "time"

    log "github.com/thinkboy/log4go"
)

func InitHTTP() (err error) {
    // http listen
    var network, addr string
    for i := 0; i < len(Conf.HTTPAddrs); i++ {
        httpServeMux := http.NewServeMux()
        httpServeMux.HandleFunc("/1/check/status", CheckStatus)
        log.Info("start http listen:\"%s\"", Conf.HTTPAddrs[i])
        if network, addr, err = inet.ParseNetwork(Conf.HTTPAddrs[i]); err != nil {
            log.Error("inet.ParseNetwork() error(%v)", err)
            return
        }
        go httpListen(httpServeMux, network, addr)
    }
    return
}

func httpListen(mux *http.ServeMux, network, addr string) {
    httpServer := &http.Server{Handler: mux, ReadTimeout: Conf.HTTPReadTimeout, WriteTimeout: Conf.HTTPWriteTimeout}
    httpServer.SetKeepAlivesEnabled(true)
    l, err := net.Listen(network, addr)
    if err != nil {
        log.Error("net.Listen(\"%s\", \"%s\") error(%v)", network, addr, err)
        panic(err)
    }
    if err := httpServer.Serve(l); err != nil {
        log.Error("server.Serve() error(%v)", err)
        panic(err)
    }
}
func CheckStatus(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body string
        res  = map[string]interface{}{"status": false}
    )
    defer retPWrite(w, r, res, &body, time.Now())
    res["status"] = true
    return
}

// retPWrite marshal the result and write to client(post).
func retPWrite(w http.ResponseWriter, r *http.Request, res map[string]interface{}, body *string, start time.Time) {
    data, err := json.Marshal(res)
    if err != nil {
        log.Error("json.Marshal(\"%v\") error(%v)", res, err)
        return
    }
    dataStr := string(data)
    if _, err := w.Write([]byte(dataStr)); err != nil {
        log.Error("w.Write(\"%s\") error(%v)", dataStr, err)
    }
    log.Info("req: \"%s\", post: \"%s\", res:\"%s\", ip:\"%s\", time:\"%fs\"", r.URL.String(), *body, dataStr, r.RemoteAddr, time.Now().Sub(start).Seconds())
}
