package main

import (
    "encoding/json"
    "io/ioutil"
    "net"
    "net/http"
    "time"

    "github.com/go-redis/redis"
    log "github.com/thinkboy/log4go"
)

type RedisConfig struct {
    RedisAddr    string
    RedisPwd     string
    RedisDB      int
    SyncDelay    int
    TimeoutDelay int
}

type CometInfo struct {
    ServerId   int32
    IP         string
    ExtranetIp string
    CPU        int
    CPUUsed    float64
    Memory     int64
    MemoryUsed int64
    ConCount   int64
    LastTime   string
    Timestamp  int64
}

func InitRedis(conf RedisConfig, cometKey string) {
    if conf.RedisPwd == "null" {
        conf.RedisPwd = ""
    }
    go SyncCometInfo(conf, cometKey)
}

func SyncCometInfo(conf RedisConfig, cometKey string) {
    for {
        setComet(conf, cometKey)
        time.Sleep(time.Duration(conf.SyncDelay) * time.Second)
    }
}

func setComet(conf RedisConfig, cometKey string) {
    client := redis.NewClient(&redis.Options{
        Addr:     conf.RedisAddr,
        Password: conf.RedisPwd, // no password set
        DB:       conf.RedisDB,  // use default DB
    })
    defer client.Close()
    _, err := client.Ping().Result()
    if err != nil {
        log.Error("Redis Connect Failed %v [add:%s]", err, conf.RedisAddr)
        return
    }
    cpuInfo := CollectCPUInfo()

    memoryInfo := CollectMemoryInfo()
    info := CometInfo{
        IP:         Get_internal(),
        ExtranetIp: Get_external(),
        ServerId:   Conf.ServerId,
        CPU:        cpuInfo.CPU,
        CPUUsed:    cpuInfo.CPUUsed,
        Memory:     memoryInfo.Memory,
        MemoryUsed: memoryInfo.MemoryUsed,
        ConCount:   DefaultServer.countTcp(),
        LastTime:   time.Now().Local().String(),
        Timestamp:  time.Now().Unix(),
    }
    infoData, err := json.Marshal(info)
    if err != nil {
        log.Error("CometInfo convert string Fialed", err)
        return
    }
    err = client.Set(cometKey+":"+info.IP, infoData, time.Duration(conf.TimeoutDelay)*time.Second).Err()
    if err != nil {
        log.Error("CometInfo Set Failed", err)
        return
    }
}

var s_inner_ip string

func Get_internal() (ip string) {
    if s_inner_ip != "" {
        //log.Info("s_inner_ip %s", s_inner_ip)
        return s_inner_ip
    }

    addrs, err := net.InterfaceAddrs()
    if err != nil {
        log.Error("Get_internal Error", err.Error())
        return ""
    }
    for _, a := range addrs {
        if ipnet, ok := a.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
            if ipnet.IP.To4() != nil {
                s_inner_ip = ipnet.IP.String()
                log.Info("s_inner_ip %s", s_inner_ip)
                return s_inner_ip
            }
        }
    }
    return ""
}

var s_external_ip string

func Get_external() (extranetIp string) {
    if Conf.ExternalIp != "" {
        return Conf.ExternalIp
    }

    if s_external_ip != "" {
        //log.Info("s_external_ip %s", s_external_ip)
        return s_external_ip
    }

    resp, err := http.Get("http://myexternalip.com/raw")
    if err != nil {
        log.Error("Get_external Error", err.Error())
        return ""
    }
    defer resp.Body.Close()
    ip, err := ioutil.ReadAll(resp.Body)
    if err != nil {
        log.Error("Get_external Error", err.Error())
        return ""
    }
    s_external_ip = string(ip)
    log.Info("s_external_ip %s", s_external_ip)
    return s_external_ip
}
