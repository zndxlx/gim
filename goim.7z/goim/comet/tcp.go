package main

import (
    //"goim/libs/bufio"
    "encoding/json"
    "fmt"
    log "github.com/thinkboy/log4go"
    "goim/libs/bytes"
    "goim/libs/define"
    "goim/libs/proto"
    itime "goim/libs/time"
    "io"
    "net"
    "strconv"
    "strings"
    "time"
)

type TvInfoEx struct {
    Fe string `json:"fe"` //支持特性
}

// InitTCP listen all tcp.bind and start accept connections.
func InitTCP(addrs []string, accept int) (err error) {
    var (
        bind     string
        listener *net.TCPListener
        addr     *net.TCPAddr
    )
    for _, bind = range addrs {
        if addr, err = net.ResolveTCPAddr("tcp4", bind); err != nil {
            log.Error("net.ResolveTCPAddr(\"tcp4\", \"%s\") error(%v)", bind, err)
            return
        }
        if listener, err = net.ListenTCP("tcp4", addr); err != nil {
            log.Error("net.ListenTCP(\"tcp4\", \"%s\") error(%v)", bind, err)
            return
        }
        if Debug {
            log.Debug("start tcp listen: \"%s\"", bind)
        }
        // split N core accept
        for i := 0; i < accept; i++ {
            go acceptTCP(DefaultServer, listener)
        }
    }
    return
}

// Accept accepts connections on the listener and serves requests
// for each incoming connection.  Accept blocks; the caller typically
// invokes it in a go statement.
func acceptTCP(server *Server, lis *net.TCPListener) {
    var (
        conn *net.TCPConn
        err  error
        r    int
    )
    for {
        if conn, err = lis.AcceptTCP(); err != nil {
            // if listener close then return
            log.Error("listener.Accept(\"%s\") error(%v)", lis.Addr().String(), err)
            return
        }
        if err = conn.SetKeepAlive(server.Options.TCPKeepalive); err != nil {
            log.Error("conn.SetKeepAlive() error(%v)", err)
            return
        }
        if err = conn.SetReadBuffer(server.Options.TCPRcvbuf); err != nil {
            log.Error("conn.SetReadBuffer() error(%v)", err)
            return
        }
        if err = conn.SetWriteBuffer(server.Options.TCPSndbuf); err != nil {
            log.Error("conn.SetWriteBuffer() error(%v)", err)
            return
        }
        go serveTCP(server, conn, r)
        if r++; r == maxInt {
            r = 0
        }
    }
}

func serveTCP(server *Server, conn *net.TCPConn, r int) {
    var (
        // timer
        tr  = server.round.Timer(r)
        rp  = server.round.Reader(r)
    )
    if Debug {
        var (
            // ip addr
            lAddr = conn.LocalAddr().String()
            rAddr = conn.RemoteAddr().String()
        )
        log.Debug("start tcp serve \"%s\" with \"%s\"", lAddr, rAddr)
    }
    server.serveTCP(conn, rp, tr)
}

// TODO linger close?
func (server *Server) serveTCP(conn *net.TCPConn, rp *bytes.Pool, tr *itime.Timer) {
    var (
        err        error
        key        string
        white      bool
        b          *Bucket
        trd        *itime.TimerData
        rb         = rp.Get()
        ch         = NewChannel(define.NoRoom, conn)
        rr         = &ch.Reader
        clientAddr = conn.RemoteAddr().String()
    )
    ch.Reader.ResetBuffer(conn, rb.Bytes())

    // handshake
    trd = tr.Add(server.Options.HandshakeTimeout, func() {
        log.Error("key: %s handshake or heart beat time out", key)
        if white {
            DefaultWhitelist.Log.Printf("key: %s handshake or heart beat time out\n", key)
        }
        if err = conn.Close(); err != nil {
            log.Error("conn close error(%v)", key, err)
        }
    })

    if key, ch.RoomId, err = server.authTCP(ch, clientAddr); err == nil {
        b = server.Bucket(key)
        err = b.Put(key, ch)
        log.Info("key: %s RoomId %v, handshake success", key, ch.RoomId)
    }

    if err != nil {
        conn.Close()
        rp.Put(rb)
        tr.Del(trd)
        log.Error("key: %s handshake failed error(%v)", key, err)
        return
    }
    trd.Key = key
    tr.Set(trd, time.Second*time.Duration(DefaultHeartInterval*3+10))
    white = DefaultWhitelist.Contains(key)
    if white {
        DefaultWhitelist.Log.Printf("key: %s RoomId %v, handshake success\n", key, ch.RoomId)
    }
    ch.White = white
    appStr := strconv.Itoa(int(ch.RoomId))
    AppConnCount.WithLabelValues(appStr).Inc()
    for {
        p_read := &proto.Proto{}

        if err = p_read.ReadTCP(rr); err != nil {
            goto failed
        }

        if white {
            DefaultWhitelist.Log.Printf("key: %s read proto:%v\n", key, p_read.String())
        }
        if p_read.Operation == define.OP_HEARTBEAT {
            if ch.DHeart {
                heartInterval := ch.GetHeartInterval()
                ch.SendHeartWithInterval(heartInterval)
                ch.UpdateLastHeartInterval(heartInterval)
                tr.Set(trd, time.Second*time.Duration(heartInterval*3+10))
            } else {
                ch.SendHeartBeat()
                tr.Set(trd, time.Second*time.Duration(DefaultHeartInterval*3+10))
            }
        } else if p_read.Operation == define.OP_UPDATE {
            if err = server.operator.Update(p_read, clientAddr); err != nil {
                err = ErrUpdateCap
            }
            p_read.Body = nil
            p_read.Operation = define.OP_UPDATE_REPLY
            SendMsg(key, p_read)
        } else if p_read.Operation == define.OP_SYNC_MSG {
            log.Info("key: %s, recv sync msg, proto:%v\n", key, p_read.String())
            server.processSyncMsg(ch, p_read)
        } else if p_read.Operation == define.OP_ACK_MSG {
            log.Info("key: %s, recv ack msg, proto:%v\n", key, p_read.String())
            server.processAckMsg(ch, p_read)
        } else {
            if err = server.operator.Operate(p_read); err != nil {
                goto failed
            }
            SendMsg(key, p_read)
        }
    }

failed:
    if white {
        DefaultWhitelist.Log.Printf("key: %s server tcp error(%v)\n", key, err)
    }
    if err != nil && err != io.EOF {
        log.Info("key: %s server tcp failed error(%v)", key, err)
    }
    b.Del(key)
    tr.Del(trd)
    rp.Put(rb)

    if err = conn.Close(); err != nil {
        //log.Error("%s conn close error(%v)", key, err)
    }

    if err = server.operator.Disconnect(key, ch.RoomId); err != nil {
        log.Error("key: %s operator do disconnect error(%v)", key, err)
    }
    if white {
        DefaultWhitelist.Log.Printf("key: %s disconnect error(%v)\n", key, err)
    }

    log.Info("key: %s server tcp goroutine exit", key)

    AppConnCount.WithLabelValues(appStr).Dec()
    return
}

// auth for goim handshake with client, use rsa & aes.
func (server *Server) authTCP(ch *Channel, clientAddr string) (key string, rid int32, err error) {
    p := &proto.Proto{}
    if err = p.ReadTCP(&ch.Reader); err != nil {
        log.Debug("auth ReadTCP error: %s", err.Error())
        return
    }
    if p.Operation != define.OP_AUTH {
        log.Debug("auth operation not valid: %d", p.Operation)
        err = ErrOperation
        return
    }
    var (
        lastMsgID    int64
        lastAckMsgId int64
    )
    if key, rid, lastMsgID, lastAckMsgId, err = server.operator.Connect(p, clientAddr); err != nil {
        return
    }

    //判断是否支持动态心跳
    token := string(p.Body)
    tks := strings.Split(token, ";")
    if len(tks) > 2 {
        cap := tks[1]
        var tvInfoEx TvInfoEx
        if tmpErr := json.Unmarshal([]byte(cap), &tvInfoEx); tmpErr != nil {
            log.Info("tmpErr=%v", tmpErr)
        } else {
            if len(tvInfoEx.Fe) > 1 && tvInfoEx.Fe[1] == '1' {
                ch.DHeart = true
            }
        }
        log.Debug("cap %s, tvInfoEx %v, ch.DHeart %v", cap, tvInfoEx, ch.DHeart)
    }

    ch.Key = key
    p.Body = []byte(fmt.Sprintf(`{"lastAck":"%v","lastMsg":"%v"}`, lastAckMsgId, lastMsgID))
    p.Operation = define.OP_AUTH_REPLY
    if err = ch.WriteTCP(p); err != nil {
        return
    }
    return
}
func (server *Server) countTcp() (conCount int64) {
    conCount = 0
    for _, bucket := range server.Buckets {
        conCount += int64(len(bucket.chs))
    }
    return conCount
}

func (server *Server) processSyncMsg(ch *Channel, p *proto.Proto) {
    var req proto.CSyncMsgReq
    var rsp proto.CSyncMsgRsp

    defer func() {
        log.Error("rsp=%+v,rsp.Msgs=%p", rsp, rsp.Msgs)
        if rsp.Msgs == nil {
            rsp.Msgs = make([]proto.Message, 0)
        }
        p.Operation = define.OP_SYNC_MSG_REPLY
        b, err := json.Marshal(rsp)
        if err != nil {
            log.Error("key %v, Marshal req failed, err=%v", ch.Key, err)
            rsp.Ret = 500 //服务器错误
        } else {
            p.Body = b
        }
        SendMsg(ch.Key, p)
    }()

    err := json.Unmarshal(p.Body, &req)
    if err != nil {
        log.Error("key %v, Unmarshal req failed, body=%v, err=%v", ch.Key, string(p.Body), err)
        rsp.Ret = 400 //请求错误
    }

    if rsp.Msgs, err = server.operator.syncMsg(ch.Key, ch.RoomId, req.MsgID); err != nil {
        rsp.Ret = 500 //服务器错误
        log.Error("key %v, Sync rpc failed, err=%v", ch.Key, err)
        return
    }
    rsp.Ret = 200 //成功
    return
}

func (server *Server) processAckMsg(ch *Channel, p *proto.Proto) {
    var req proto.CAckMsgReq
    err := json.Unmarshal(p.Body, &req)
    if err != nil {
        log.Error("key %v, Unmarshal req failed, body=%v, err=%v", ch.Key, string(p.Body), err)
        return
    }

    if err = server.operator.AckMsg(ch.Key, ch.RoomId, req.MsgIDs); err != nil {
        log.Error("key %v, ackmsg rpc failed, err=%v", ch.Key, err)
        return
    }

    return
}
