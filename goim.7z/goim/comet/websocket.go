package main

import (
    "crypto/tls"
    "goim/libs/define"
    "goim/libs/proto"
    itime "goim/libs/time"
    "math/rand"
    "net"
    "net/http"
    "time"

    "encoding/json"
    "fmt"
    "github.com/gorilla/websocket"
    log "github.com/thinkboy/log4go"
)

var upgrader = websocket.Upgrader{
    ReadBufferSize:  4096,
    WriteBufferSize: 4096,
    CheckOrigin: func(r *http.Request) bool {
        return true
    },
}

func InitWebsocket(addrs []string) (err error) {
    var (
        bind         string
        listener     *net.TCPListener
        addr         *net.TCPAddr
        httpServeMux = http.NewServeMux()
        server       *http.Server
    )
    httpServeMux.HandleFunc("/sub", ServeWebSocket)

    for _, bind = range addrs {
        if addr, err = net.ResolveTCPAddr("tcp4", bind); err != nil {
            log.Error("net.ResolveTCPAddr(\"tcp4\", \"%s\") error(%v)", bind, err)
            return
        }
        if listener, err = net.ListenTCP("tcp4", addr); err != nil {
            log.Error("net.ListenTCP(\"tcp4\", \"%s\") error(%v)", bind, err)
            return
        }
        server = &http.Server{Handler: httpServeMux}
        if Debug {
            log.Debug("start websocket listen: \"%s\"", bind)
        }
        go func(host string) {
            if err = server.Serve(listener); err != nil {
                log.Error("server.Serve(\"%s\") error(%v)", host, err)
                panic(err)
            }
        }(bind)
    }
    return
}

func InitWebsocketWithTLS(addrs []string, cert, priv string) (err error) {
    var (
        httpServeMux = http.NewServeMux()
    )
    httpServeMux.HandleFunc("/sub", ServeWebSocket)
    config := &tls.Config{}
    config.Certificates = make([]tls.Certificate, 1)
    if config.Certificates[0], err = tls.LoadX509KeyPair(cert, priv); err != nil {
        return
    }
    for _, bind := range addrs {
        server := &http.Server{Addr: bind, Handler: httpServeMux}
        server.SetKeepAlivesEnabled(true)
        if Debug {
            log.Debug("start websocket wss listen: \"%s\"", bind)
        }
        go func(host string) {
            ln, err := net.Listen("tcp", host)
            if err != nil {
                return
            }

            tlsListener := tls.NewListener(ln, config)
            if err = server.Serve(tlsListener); err != nil {
                log.Error("server.Serve(\"%s\") error(%v)", host, err)
                return
            }
        }(bind)
    }
    return
}

func ServeWebSocket(w http.ResponseWriter, req *http.Request) {
    if req.Method != "GET" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    ws, err := upgrader.Upgrade(w, req, nil)
    if err != nil {
        log.Error("Websocket Upgrade error(%v), userAgent(%s)", err, req.UserAgent())
        return
    }
    defer ws.Close()
    var (
        lAddr = ws.LocalAddr()
        rAddr = ws.RemoteAddr()
        tr    = DefaultServer.round.Timer(rand.Int())
    )
    log.Debug("start websocket serve \"%s\" with \"%s\"", lAddr, rAddr)
    DefaultServer.serveWebsocket(ws, tr)
}

func (server *Server) serveWebsocket(conn *websocket.Conn, tr *itime.Timer) {
    var (
        err error
        key string
        hb  time.Duration // heartbeat
        b   *Bucket
        trd *itime.TimerData
        ch  = NewWebChannel(define.NoRoom, conn)
    )
    hb = time.Second * time.Duration(DefaultHeartInterval)
    // handshake
    trd = tr.Add(server.Options.HandshakeTimeout, func() {
        log.Info("websocket key: %s, time out", key)
        conn.Close()
    })

    if key, ch.RoomId, err = server.authWebsocket(ch, conn, conn.RemoteAddr().String()); err == nil {
        b = server.Bucket(key)
        err = b.Put(key, ch)
        log.Info("websocket key: %s RoomId %v, handshake success", key, ch.RoomId)
    }

    if err != nil {
        conn.Close()
        tr.Del(trd)
        log.Error("handshake failed error(%v)", err)
        return
    }
    trd.Key = key
    tr.Set(trd, hb)

    for {
        p := &proto.Proto{}
        if err = p.ReadWebsocket(conn); err != nil {
            break
        }
        //p.Time = *globalNowTime
        if p.Operation == define.OP_HEARTBEAT {
            // heartbeat
            tr.Set(trd, hb)
            p.Body = nil
            p.Operation = define.OP_HEARTBEAT_REPLY
            SendMsg(key, p)
        } else if p.Operation == define.OP_SYNC_MSG {
            log.Info("key: %s, recv sync msg, proto:%v\n", key, p.String())
            server.processWebSyncMsg(ch, p)
        } else if p.Operation == define.OP_ACK_MSG {
            log.Info("key: %s, recv ack msg, proto:%v\n", key, p.String())
            server.processWebAckMsg(ch, p)
        } else {
            // process message
            if err = server.operator.Operate(p); err != nil {
                break
            }
            SendMsg(key, p)
        }
    }
    
    log.Error("key: %s server websocket failed error(%v)", key, err)
    tr.Del(trd)
    conn.Close()
    ch.Close()
    b.Del(key)
    if err = server.operator.Disconnect(key, ch.RoomId); err != nil {
        log.Error("key: %s operator do disconnect error(%v)", key, err)
    }
    if Debug {
        log.Debug("key: %s server websocket goroutine exit", key)
    }
    return
}

func (server *Server) authWebsocket(ch *Channel, conn *websocket.Conn, clientAddr string) (key string, rid int32, err error) {
    pAuth := &proto.AuthProto{}
    if err = conn.ReadJSON(pAuth); err != nil {
        log.Debug("websocket auth ReadWebsocket error: %s", err.Error())
        return
    }
    log.Info("recv msg, proto:%v", pAuth)
    // if len(p.Body) < 2 {
    //     err = ErrHandshake
    //     return
    // }
   // p.Body = p.Body[1 : len(p.Body)-1]
    if pAuth.Operation != define.OP_AUTH {
        err = ErrOperation
        return
    }
    var (
        lastMsgID    int64
        lastAckMsgId int64
        p = &proto.Proto{Ver:pAuth.Ver, Operation:pAuth.Operation, Body:[]byte(pAuth.Body)}
    )
    if key, rid, lastMsgID, lastAckMsgId, err = server.operator.Connect(p, clientAddr); err != nil {
        return
    }
    ch.Key = key
    p.Body = []byte(fmt.Sprintf(`{"lastAck":"%v","lastMsg":"%v"}`, lastAckMsgId, lastMsgID))
    p.Operation = define.OP_AUTH_REPLY
    err = p.WriteWebsocket(conn)
    return
}

func (server *Server) processWebSyncMsg(ch *Channel, p *proto.Proto) {
    var req proto.CSyncMsgReq
    var rsp proto.CSyncMsgRsp
    log.Error("2222222222 key %v", ch.Key)
    defer func() {
        // log.Error("rsp=%+v,rsp.Msgs=%p", rsp, rsp.Msgs)
        if rsp.Msgs == nil {
            rsp.Msgs = make([]proto.Message, 0)
        }
        p.Operation = define.OP_SYNC_MSG_REPLY
        b, err := json.Marshal(rsp)
        if err != nil {
            log.Error("key %v, Marshal req failed, err=%v", ch.Key, err)
            rsp.Ret = 500 //服务器错误
        } else {
            p.Body = b
        }
        log.Error("11111111 key %v", ch.Key)
        SendMsg(ch.Key, p)
    }()

    err := json.Unmarshal(p.Body, &req)
    if err != nil {
        log.Error("key %v, Unmarshal req failed, body=%v, err=%v", ch.Key, string(p.Body), err)
        rsp.Ret = 400 //请求错误
        return
    }

    if rsp.Msgs, err = server.operator.syncMsg(ch.Key, ch.RoomId, req.MsgID); err != nil {
        rsp.Ret = 500 //服务器错误
        log.Error("key %v, Sync rpc failed, err=%v", ch.Key, err)
        return
    }
    rsp.Ret = 200 //成功
    return
}

func (server *Server) processWebAckMsg(ch *Channel, p *proto.Proto) {
    var req proto.CAckMsgReq
    err := json.Unmarshal(p.Body, &req)
    if err != nil {
        log.Error("key %v, Unmarshal req failed, body=%v, err=%v", ch.Key, string(p.Body), err)
        return
    }

    if err = server.operator.AckMsg(ch.Key, ch.RoomId, req.MsgIDs); err != nil {
        log.Error("key %v, ackmsg rpc failed, err=%v", ch.Key, err)
        return
    }

    return
}
