package main

import (
    "testing"
)

func TestBucket(t *testing.T) {
}
