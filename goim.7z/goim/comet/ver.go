package main

const (
    Ver = "0.1"
)
