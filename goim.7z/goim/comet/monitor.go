package main

import (
    "fmt"
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
    log "github.com/thinkboy/log4go"
    "net/http"
)

type Monitor struct {
}

var (
    TcpConnCount = prometheus.NewGaugeFunc(
        prometheus.GaugeOpts{
            Name: "current_comet_tcp_connect_number",
            Help: "current comet tcp connect number",
        },
        func() float64 { return float64(DefaultServer.countTcp()) },
    )

    PushMsgCount = prometheus.NewCounterVec(
        prometheus.CounterOpts{
            Name: "comet_push_msg_count",
            Help: "comet push msg count",
        },
        []string{"status"},
    )

    AppConnCount = prometheus.NewGaugeVec(
        prometheus.GaugeOpts{
            Name: "app_tcp_connect_number",
            Help: "app tcp connect number",
        },
        []string{"appid"},
    )
)

// StartPprof start http monitor.
func InitMonitor(binds []string) {
    m := new(Monitor)
    monitorServeMux := http.NewServeMux()
    monitorServeMux.HandleFunc("/monitor/ping", m.Ping)
    monitorServeMux.Handle("/metrics", promhttp.Handler())
    for _, addr := range binds {
        go func(bind string) {
            if err := http.ListenAndServe(bind, monitorServeMux); err != nil {
                log.Error("http.ListenAndServe(\"%s\", pprofServeMux) error(%v)", addr, err)
                panic(err)
            }
        }(addr)
    }

    prometheus.MustRegister(TcpConnCount)
    prometheus.MustRegister(PushMsgCount)
    prometheus.MustRegister(AppConnCount)
}

// monitor ping
func (m *Monitor) Ping(w http.ResponseWriter, r *http.Request) {
    if err := logicRpcClient.Available(); err != nil {
        http.Error(w, fmt.Sprintf("ping rpc error(%v)", err), http.StatusInternalServerError)
        return
    }
    w.Write([]byte("ok"))
}
