package main

func init() {
    Conf = new(Config)
}
