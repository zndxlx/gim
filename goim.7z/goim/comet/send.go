package main

import (
    //"goim/libs/bytes"
    //"goim/libs/define"
    "goim/libs/proto"
    //"net"
    //"time"

    log "github.com/thinkboy/log4go"
)

type msgInfo struct {
    chKey string
    proto *proto.Proto
}

var msgInfoChan chan *msgInfo

func InitSendWork() {
    msgInfoChan = make(chan *msgInfo, Conf.SendChanSize)

    for i := 0; i < Conf.SendPoolSize; i++ {
        go sendProc()
    }
}

func SendMsg(key string, p *proto.Proto) (err error) {
    m := &msgInfo{chKey: key, proto: p}
    log.Info("111111 key=%v\n", key)
    select {
    case msgInfoChan <- m:
    default: //非阻塞,发送不出去丢弃
        log.Error("%v, write error:channel full, %v\n", key, p.String())
        if DefaultWhitelist.Contains(key) {
            DefaultWhitelist.Log.Printf("%v, write error:channel full, %v\n",
                key, p.String())
        }

        PushMsgCount.WithLabelValues("full").Inc()
        err = ErrSendFull
    }
    return
}

func sendProc() {
    for {
        msg := <-msgInfoChan

        bucket := DefaultServer.Bucket(msg.chKey)
        if channel := bucket.Channel(msg.chKey); channel != nil {
            channel.WriteProto(msg.proto)
        } else {
            log.Error("%v, write error: not found channel,  %v\n", msg.chKey, msg.proto.String())
            if DefaultWhitelist.Contains(msg.chKey) {
                DefaultWhitelist.Log.Printf("%v, write error: not found channel, %v\n",
                    msg.chKey, msg.proto.String())
            }
            PushMsgCount.WithLabelValues("find_channel_err").Inc()
        }
    }
}
