(function(win) {
    var Client = function(options) {
        var MAX_CONNECT_TIME = 10;
        var DELAY = 15000;
        this.options = options || {};
        this.createConnect(MAX_CONNECT_TIME, DELAY);
    }

    Client.prototype.createConnect = function(max, delay) {
        var self = this;
        if (max === 0) {
            return;
        }
        connect();

        var heartbeatInterval;


        function connect() {
            var ws = new WebSocket('ws://47.112.113.131:8090/sub');
            var auth = false;
            var gLastMsg
            var gLastAck
            var gLastRecv

            ws.onopen = function() {
                console.log("websocket is open")
                getAuth();
            }

            ws.onmessage = function(evt) {
                //console.log(evt.data)
                var receives = JSON.parse(evt.data)
                for(var i=0; i<receives.length; i++) {
                    var data = receives[i]
                    if (data.op == 8) { //8 鉴权响应
                        auth = true;
                        console.log("recv auth rsp, ", data)
                        heartbeat();
                        heartbeatInterval = setInterval(heartbeat, 30 * 1000);
                        gLastMsg = data.body.lastMsg
                        gLastAck = data.body.lastAck
                        gLastRecv = data.body.lastAck
                        if (gLastAck != gLastMsg) {
                            syncMsg(gLastAck)
                        }
                        // console.log("gLastMsg:", gLastMsg, "gLastAck", gLastAck, "gLastRecv", gLastRecv)
                    }
                    if (!auth) {
                        setTimeout(getAuth, delay);
                    }else {
                        if (data.op == 5) {  //5  即时消息
                            console.log("recv msg, " , data)
                            var notify = self.options.notify;
                            if(notify) notify(data.body);
                        }else if (data.op == 18) {  //18 同步消息响应
                            console.log("recv sync msg rsp, ", data)
                            var msgIDs = [];
                            for(var i=0; i<data.body.msgs.length; i++) {
                                var msg = data.body.msgs[i]
                                if (msg.msgID > gLastRecv){
                                    gLastRecv = msg.msgID
                                }
                                msgIDs.push(msg.msgID)
                            }
                            console.log("gLastMsg:", gLastMsg, "gLastAck", gLastAck, "gLastRecv", gLastRecv)
                            ackMsg(msgIDs)
                        } else if (data.op == 20){  //20 新消息通知
                            console.log("recv msg notify, ", data)
                            syncMsg(gLastRecv)
                        } else if (data.op == 3){  //3 心跳响应
                            console.log("recv heart rsp, ", data)
                        }
                    }
                }
            }

            ws.onclose = function() {
                console.log("websocket is close")
                if (heartbeatInterval) clearInterval(heartbeatInterval);
                setTimeout(reConnect, delay);
            }

            function heartbeat() {
                heartBody = JSON.stringify({
                    'ver': 1,
                    'op': 2,
                    'seq': 2,
                    'body': {}
                })
                ws.send(heartBody);
                console.log("send heart: "+ heartBody)
            }

            function getAuth() {
                authBody = JSON.stringify({
                    'ver': 1,
                    'op': 7,
                    'seq': 1,
                    'body': '10000;{"ver":"2.0"};14'
                })
                ws.send(authBody);
                console.log("send auth: "+ authBody)
            }

            function syncMsg(msgID) {
                syncBody = JSON.stringify({
                    'ver': 1,
                    'op': 17,            //17 同步消息请求
                    'seq': 3,
                    'body': {'msgId':msgID}
                })
                ws.send(syncBody);
                console.log("send sync: "+ syncBody)
            }

            function ackMsg(msgIDs) {
                ackBody = JSON.stringify({
                    'ver': 1,
                    'op': 19,    //19 同步消息应答
                    'seq': 4,
                    'body': {'msgIDs':msgIDs}
                })
                ws.send(ackBody);
                console.log("send ack: "+ ackBody)
            }

        }

        function reConnect() {
            self.createConnect(--max, delay * 2);
        }
    }

    win['MyClient'] = Client;
})(window);
