package main

import (
    "encoding/json"
    "errors"
    protobuf "github.com/golang/protobuf/proto"
    log "github.com/thinkboy/log4go"
    inet "goim/libs/net"
    "goim/libs/pb"
    "goim/libs/proto"
    "io/ioutil"
    "net"
    "net/http"
    "strconv"
    "strings"
    "time"
)

func InitHTTP() (err error) {
    // http listen
    var network, addr string
    for i := 0; i < len(Conf.HTTPAddrs); i++ {
        httpServeMux := http.NewServeMux()
        httpServeMux.HandleFunc("/1/push", Push)
        httpServeMux.HandleFunc("/1/rpush", RPush)
        httpServeMux.HandleFunc("/1/pushs", Pushs)
        httpServeMux.HandleFunc("/1/push/all", PushAll)
        httpServeMux.HandleFunc("/1/push/room", PushRoom)
        httpServeMux.HandleFunc("/1/server/del", DelServer)
        httpServeMux.HandleFunc("/1/count", Count)
        httpServeMux.HandleFunc("/1/client/info", GetInfo)
        httpServeMux.HandleFunc("/1/client/del", DelInfo)
        httpServeMux.HandleFunc("/1/check/status", CheckStatus)
        httpServeMux.HandleFunc("/1/bssid/tvs", GetBssidTvs)
        log.Info("start http listen:\"%s\"", Conf.HTTPAddrs[i])
        if network, addr, err = inet.ParseNetwork(Conf.HTTPAddrs[i]); err != nil {
            log.Error("inet.ParseNetwork() error(%v)", err)
            return
        }
        go httpListen(httpServeMux, network, addr)
    }
    return
}

func httpListen(mux *http.ServeMux, network, addr string) {
    httpServer := &http.Server{Handler: mux, ReadTimeout: Conf.HTTPReadTimeout, WriteTimeout: Conf.HTTPWriteTimeout}
    httpServer.SetKeepAlivesEnabled(true)
    l, err := net.Listen(network, addr)
    if err != nil {
        log.Error("net.Listen(\"%s\", \"%s\") error(%v)", network, addr, err)
        panic(err)
    }
    if err := httpServer.Serve(l); err != nil {
        log.Error("server.Serve() error(%v)", err)
        panic(err)
    }
}

// retWrite marshal the result and write to client(get).
func retWrite(w http.ResponseWriter, r *http.Request, res map[string]interface{}, start time.Time) {
    data, err := json.Marshal(res)
    if err != nil {
        log.Error("json.Marshal(\"%v\") error(%v)", res, err)
        return
    }
    dataStr := string(data)
    if _, err := w.Write([]byte(dataStr)); err != nil {
        log.Error("w.Write(\"%s\") error(%v)", dataStr, err)
    }
    log.Info("req: \"%s\", get: res:\"%s\", ip:\"%s\", time:\"%fs\"", r.URL.String(), dataStr, r.RemoteAddr, time.Now().Sub(start).Seconds())
}

// retPWrite marshal the result and write to client(post).
func retPWrite(w http.ResponseWriter, r *http.Request, res map[string]interface{}, body *string, start time.Time) {
    data, err := json.Marshal(res)
    if err != nil {
        log.Error("json.Marshal(\"%v\") error(%v)", res, err)
        return
    }
    dataStr := string(data)
    if _, err := w.Write([]byte(dataStr)); err != nil {
        log.Error("w.Write(\"%s\") error(%v)", dataStr, err)
    }
    log.Info("req: \"%s\", post: \"%s\", res:\"%s\", ip:\"%s\", time:\"%fs\"", r.URL.String(), *body, dataStr, r.RemoteAddr, time.Now().Sub(start).Seconds())
}

func RPush(w http.ResponseWriter, r *http.Request) {
    if r.Method != "POST" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body      string
        bodyBytes []byte
        uid       int64
        err       error
        res       = map[string]interface{}{"ret": OK}
        uidStr    = r.URL.Query().Get("uid")
        appidStr  = r.URL.Query().Get("appid")
        ackopStr  = r.URL.Query().Get("ackop")
        appid     int32
        ackop     int32
        now       = time.Now()
    )
    defer retPWrite(w, r, res, &body, now)
    if bodyBytes, err = ioutil.ReadAll(r.Body); err != nil {
        log.Error("ioutil.ReadAll() failed (%s)", err)
        res["ret"] = InternalErr
        return
    }
    body = string(bodyBytes)

    if uidStr == "" || appidStr == "" {
        res["ret"] = ReqParaErr
        res["msg"] = "no uid or appid"
        return
    }

    if uid, err = strconv.ParseInt(uidStr, 10, 64); err != nil {
        log.Error("strconv.Atoi(\"%s\") error(%v)", uidStr, err)
        res["ret"] = ReqParaErr
        res["msg"] = "uid Atoi err"
        return
    }

    if appidTmp, err := strconv.ParseInt(appidStr, 10, 32); err != nil {
        log.Error("strconv.Atoi(\"%s\") error(%v)", appidStr, err)
        res["ret"] = ReqParaErr
        res["msg"] = "appid Atoi err"
        return
    } else {
        appid = int32(appidTmp)
    }

    if ackopStr != "" {
        if ackopTmp, err := strconv.ParseInt(ackopStr, 10, 32); err != nil {
            log.Error("strconv.Atoi(\"%s\") error(%v)", ackopStr, err)
            res["ret"] = ReqParaErr
            res["msg"] = "ackop Atoi err"
            return
        } else {
            ackop = int32(ackopTmp)
        }
    }

    userInfo, err := GetUserInfo(uid, appid)
    if err != nil {
        res["ret"] = InternalErr
        res["msg"] = "get user info failed"
        return
    }

    if userInfo.Ver < "2.0" {
        res["ret"] = ReqParaErr
        res["msg"] = "user version not support"
        return
    }

    msgid := gSnowNode.Generate().Int64()
    storeMsg := &pb.StoreMessage{MsgId: msgid, MsgBody: body, AckOp: ackop, SendTime: now.Unix()}
    message, err := protobuf.Marshal(storeMsg)
    if err != nil {
        res["ret"] = InternalErr
        res["msg"] = "marshal message failed"
        return
    }

    err = AddMsg2Queue(uid, appid, message, msgid)
    if err != nil {
        res["ret"] = InternalErr
        res["msg"] = "store msg to redis failed"
        return
    }

    UpdateUserLastMsg(uid, appid, msgid)

    go func() {
        subKeys := genSubKeyWithAppid(uid, appid)
        for serverId, keys := range subKeys {
            NotifyMsg(serverId, keys, msgid)
        }
    }()

    res["msgid"] = msgid
    res["ret"] = OK
    return
}

func Push(w http.ResponseWriter, r *http.Request) {
    if r.Method != "POST" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body      string
        serverId  int32
        keys      []string
        subKeys   map[int32][]string
        bodyBytes []byte
        userId    int64
        err       error
        res       = map[string]interface{}{"ret": OK}
        uidStr    = r.URL.Query().Get("uid")
        appidStr  = r.URL.Query().Get("appid")
        appid     int32
    )
    defer retPWrite(w, r, res, &body, time.Now())
    if bodyBytes, err = ioutil.ReadAll(r.Body); err != nil {
        log.Error("ioutil.ReadAll() failed (%s)", err)
        res["ret"] = InternalErr
        return
    }
    body = string(bodyBytes)
    ip := r.Header.Get("Remote_addr")
    if ip == "" {
        ip = r.RemoteAddr
    }
    if err = WhiteCheck(ip, body); err != nil {
        log.Error("White Check Failed (%s)", err)
        res["ret"] = InternalErr
        return
    }
    if userId, err = strconv.ParseInt(uidStr, 10, 64); err != nil {
        log.Error("strconv.Atoi(\"%s\") error(%v)", uidStr, err)
        res["ret"] = InternalErr
        return
    }
    if appidStr != "" {
        if appidTmp, err := strconv.ParseInt(appidStr, 10, 32); err != nil {
            log.Error("strconv.Atoi(\"%s\") error(%v)", appidStr, err)
            res["ret"] = InternalErr
            return
        } else {
            appid = int32(appidTmp)
        }

    }

    // subKeys := make(map[int32][]string)
    if appid != 0 {
        subKeys = genSubKeyWithAppid(userId, appid)
    } else {
        subKeys = genSubKey(userId)
    }

    if len(subKeys) == 0 {
        log.Error("get uid:%v, appid:%v subkeys failed, maybe not online", userId, appid)
        res["ret"] = InternalErr
        return
    }
    for serverId, keys = range subKeys {
        if err = mpushKafka(serverId, keys, bodyBytes); err != nil {
            res["ret"] = InternalErr
            return
        }
    }
    res["ret"] = OK
    return
}

func WhiteCheck(remoteIp, body string) (err error) {
    if !Conf.WhiteOpen {
        return nil
    }
    var ip string
    ip = strings.Split(remoteIp, ":")[0]
    //	log.Info("remoteIp:%s wips:%v", ip, Conf.WhiteIps)
    for _, ipVal := range Conf.WhiteIps {
        if ip == ipVal {
            //			log.Info("same ip %s = %s", remoteIp, ipVal)
            return nil
        }
    }
    bs := strings.Split(body, ",")
    if len(bs) < 1 {
        return
    }
    //	log.Info("body split = %s", bs)
    var action int64
    if action, err = strconv.ParseInt(bs[0], 16, 64); err != nil {
        return
    }
    log.Info("remoteIp:%s,action:%s ", ip, action)
    for _, actVal := range Conf.WhiteActions {
        if action == actVal {
            return nil
        }
    }
    return errors.New("Action Not Allowed")
}

type pushsBodyMsg struct {
    Msg     json.RawMessage `json:"m"`
    UserIds []int64         `json:"u"`
}

func parsePushsBody(body []byte) (msg []byte, userIds []int64, err error) {
    tmp := pushsBodyMsg{}
    if err = json.Unmarshal(body, &tmp); err != nil {
        return
    }
    msg = tmp.Msg
    userIds = tmp.UserIds
    return
}

// {"m":{"test":1},"u":"1,2,3"}
func Pushs(w http.ResponseWriter, r *http.Request) {
    if r.Method != "POST" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body      string
        bodyBytes []byte
        serverId  int32
        userIds   []int64
        err       error
        res       = map[string]interface{}{"ret": OK}
        subKeys   map[int32][]string
        keys      []string
    )
    defer retPWrite(w, r, res, &body, time.Now())
    if bodyBytes, err = ioutil.ReadAll(r.Body); err != nil {
        log.Error("ioutil.ReadAll() failed (%s)", err)
        res["ret"] = InternalErr
        return
    }
    body = string(bodyBytes)
    if bodyBytes, userIds, err = parsePushsBody(bodyBytes); err != nil {
        log.Error("parsePushsBody(\"%s\") error(%s)", body, err)
        res["ret"] = InternalErr
        return
    }
    subKeys = genSubKeys(userIds)
    for serverId, keys = range subKeys {
        if err = mpushKafka(serverId, keys, bodyBytes); err != nil {
            res["ret"] = InternalErr
            return
        }
    }
    res["ret"] = OK
    return
}

func PushRoom(w http.ResponseWriter, r *http.Request) {
    if r.Method != "POST" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        bodyBytes []byte
        body      string
        rid       int
        err       error
        param     = r.URL.Query()
        res       = map[string]interface{}{"ret": OK}
    )
    defer retPWrite(w, r, res, &body, time.Now())
    if bodyBytes, err = ioutil.ReadAll(r.Body); err != nil {
        log.Error("ioutil.ReadAll() failed (%v)", err)
        res["ret"] = InternalErr
        return
    }
    body = string(bodyBytes)
    ip := r.Header.Get("Remote_addr")
    if ip == "" {
        ip = r.RemoteAddr
    }
    if err = WhiteCheck(ip, body); err != nil {
        log.Error("White Check Failed (%s)", err)
        res["ret"] = InternalErr
        return
    }
    ridStr := param.Get("rid")
    enable, _ := strconv.ParseBool(param.Get("ensure"))
    // push room
    if rid, err = strconv.Atoi(ridStr); err != nil {
        log.Error("strconv.Atoi(\"%s\") error(%v)", ridStr, err)
        res["ret"] = InternalErr
        return
    }
    if err = broadcastRoomKafka(int32(rid), bodyBytes, enable); err != nil {
        log.Error("broadcastRoomKafka(\"%s\",\"%s\",\"%d\") error(%s)", rid, body, enable, err)
        res["ret"] = InternalErr
        return
    }
    res["ret"] = OK
    return
}

func PushAll(w http.ResponseWriter, r *http.Request) {
    if r.Method != "POST" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        bodyBytes []byte
        body      string
        err       error
        res       = map[string]interface{}{"ret": OK}
    )
    defer retPWrite(w, r, res, &body, time.Now())
    if bodyBytes, err = ioutil.ReadAll(r.Body); err != nil {
        log.Error("ioutil.ReadAll() failed (%v)", err)
        res["ret"] = InternalErr
        return
    }
    body = string(bodyBytes)
    ip := r.Header.Get("Remote_addr")
    if ip == "" {
        ip = r.RemoteAddr
    }
    if err = WhiteCheck(ip, body); err != nil {
        log.Error("White Check Failed (%s)", err)
        res["ret"] = InternalErr
        return
    }
    // push all
    if err := broadcastKafka(bodyBytes); err != nil {
        log.Error("broadcastKafka(\"%s\") error(%s)", body, err)
        res["ret"] = InternalErr
        return
    }
    res["ret"] = OK
    return
}

type RoomCounter struct {
    RoomId int32
    Count  int32
}

type ServerCounter struct {
    Server int32
    Count  int32
}

func Count(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        typeStr = r.URL.Query().Get("type")
        res     = map[string]interface{}{"ret": OK}
    )
    defer retWrite(w, r, res, time.Now())
    if typeStr == "room" {
        d := make([]*RoomCounter, 0, len(RoomCountMap))
        for roomId, count := range RoomCountMap {
            d = append(d, &RoomCounter{RoomId: roomId, Count: count})
        }
        res["data"] = d
    } else if typeStr == "server" {
        d := make([]*ServerCounter, 0, len(ServerCountMap))
        for server, count := range ServerCountMap {
            d = append(d, &ServerCounter{Server: server, Count: count})
        }
        res["data"] = d
    }
    return
}

func DelServer(w http.ResponseWriter, r *http.Request) {
    if r.Method != "POST" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        err       error
        serverStr = r.URL.Query().Get("server")
        server    int64
        res       = map[string]interface{}{"ret": OK}
    )
    if server, err = strconv.ParseInt(serverStr, 10, 32); err != nil {
        log.Error("strconv.Atoi(\"%s\") error(%v)", serverStr, err)
        res["ret"] = InternalErr
        return
    }
    defer retWrite(w, r, res, time.Now())
    if err = delServer(int32(server)); err != nil {
        res["ret"] = InternalErr
        return
    }
    return
}

func GetInfo(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body string
        //		serverId  int32
        //		keys      []string
        subKeys map[int32][]string
        //		bodyBytes []byte
        clientInfo = &proto.ClientInfo{Status: false, Ip: "", ClientData: ""}
        userId     int64
        err        error
        uidStr     = r.URL.Query().Get("uid")
        appidStr   = r.URL.Query().Get("appid")
        appid      int32
        res        = map[string]interface{}{"uid": "", "appid": 0, "status": false, "client_ip": "", "info": "", "err": ""}
    )
    defer retPWrite(w, r, res, &body, time.Now())
    res["uid"] = uidStr
    if userId, err = strconv.ParseInt(uidStr, 10, 64); err != nil {
        log.Error("strconv.Atoi(\"%s\") error(%v)", uidStr, err)
        res["err"] = err.Error()
        return
    }
    if appidStr != "" {
        if appidTmp, err := strconv.ParseInt(appidStr, 10, 32); err != nil {
            log.Error("strconv.Atoi(\"%s\") error(%v)", appidStr, err)
            res["ret"] = InternalErr
            return
        } else {
            appid = int32(appidTmp)
        }
    }

    clientInfo, err = getClientInfo(userId)
    if err != nil {
        res["err"] = err.Error()
        log.Error("Get clientinfo(\"%s\") error(%v)", uidStr, err)
        return
    }
    if clientInfo == nil {
        return
    }
    res["status"] = clientInfo.Status
    res["client_ip"] = clientInfo.Ip
    res["appid"] = clientInfo.AppId
    res["info"] = clientInfo.ClientData

    //动态心跳，需要发送消息给comet
    if appid != 0 {
        subKeys = genSubKeyWithAppid(userId, appid)
    } else {
        subKeys = genSubKey(userId)
    }

    if len(subKeys) == 0 {
        log.Error("get uid %v, appid=%v subkeys failed, maybe not online", userId, appid)
        res["status"] = false
        return
    }
    for serverId, keys := range subKeys {
        NotifyActive(serverId, keys)
    }
    return
}

func DelInfo(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body   string
        userId int64
        err    error
        uidStr = r.URL.Query().Get("uid")
        res    = map[string]interface{}{"uid": "", "status": false, "err": ""}
    )
    defer retPWrite(w, r, res, &body, time.Now())
    res["uid"] = uidStr
    if userId, err = strconv.ParseInt(uidStr, 10, 64); err != nil {
        log.Error("strconv.Atoi(\"%s\") error(%v)", uidStr, err)
        res["err"] = err.Error()
        return
    }
    if err = delClientInfo(userId); err != nil {
        res["status"] = true
    }
    return
}

func CheckStatus(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body string
        res  = map[string]interface{}{"status": true}
    )
    defer retPWrite(w, r, res, &body, time.Now())
    return
}

func GetBssidTvs(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" {
        http.Error(w, "Method Not Allowed", 405)
        return
    }
    var (
        body  string
        err   error
        bssid = r.URL.Query().Get("bssid")
        ip    = r.URL.Query().Get("ip")
        res   = map[string]interface{}{"err": ""}
    )
    defer retPWrite(w, r, res, &body, time.Now())

    res["tvs"] = make([]map[string]interface{}, 0)

    if ip == "" {
        ip = inet.GetIP(r)
    }

    tvs, err := GetBssidTv(bssid, ip)
    if err != nil {
        log.Error("get bssid tv failed, bssid=%s, ip=%s, error(%v)", bssid, ip, err)
        res["err"] = err.Error()
        return
    }

    for uidStr, _ := range tvs {
        uid, err := strconv.ParseInt(uidStr, 10, 64)
        if err != nil {
            log.Error("strconv.Atoi(\"%s\") error(%v)", uidStr, err)
            continue
        }

        clientInfo, err := getClientInfo(uid)
        if err != nil {
            log.Error("Get clientinfo(\"%s\") error(%v)", uidStr, err)
            continue
        }

        if clientInfo == nil {
            continue
        }

        if clientInfo.Status != true {
            DelBssidTv(bssid, ip, uid)
            continue
        }

        uidInfo := map[string]interface{}{"uid": uid, "data": clientInfo.ClientData}
        res["tvs"] = append(res["tvs"].([]map[string]interface{}), uidInfo)
    }

    return

}
