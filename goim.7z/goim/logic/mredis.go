package main

import (
    "errors"
    "fmt"
    "github.com/go-redis/redis"
    protobuf "github.com/golang/protobuf/proto"
    log "github.com/thinkboy/log4go"
    "goim/libs/pb"
    "strconv"
    "time"
)

var (
    gMRedisClient *redis.Client //保存消息发送队列，客户端信息
)

func InitMRedis() {
    gMRedisClient = redis.NewClient(&redis.Options{
        Addr:     Conf.MRedisAddr,
        Password: Conf.MRedisPwd,
        DB:       Conf.MRedisDB,
        PoolSize: Conf.MRedisPool,

        IdleTimeout: 1 * time.Minute,
    })

    if _, err := gBRedisClient.Ping().Result(); err != nil {
        panic(err)
    }
}

func getMsgQueueKey(uid int64, appid int32) string {
    k := fmt.Sprintf("mq:%d:%d", appid, uid)
    return k
}

func getUserInfoKey(uid int64, appid int32) string {
    k := fmt.Sprintf("user:%d:%d", appid, uid)
    return k
}

const (
    LAST_ACK_MSG_KEY = "lastAck"
    LAST_MSG_KEY     = "lastMsg"
    VERSION_KEY      = "ver"
)

type UserInfo struct {
    LastAckMsg int64
    LastMsg    int64
    Ver        string
}

func AddMsg2Queue(uid int64, appid int32, msg []byte, msgid int64) (err error) {
    k := getMsgQueueKey(uid, appid)
    _, err = gMRedisClient.ZAdd(k, redis.Z{float64(msgid), msg}).Result()
    if err != nil {
        log.Error("redis ZAdd err, uid=%v, appid=%v, err=%v", uid, appid, err)
        return
    }
    return
}

func GetValFromQueue(uid int64, appid int32, msgid int64) (val string, err error) {
    k := getMsgQueueKey(uid, appid)
    min := fmt.Sprintf("%v", msgid)
    var vals []string
    vals, err = gMRedisClient.ZRangeByScore(k, redis.ZRangeBy{Min: min, Max: min}).Result()
    if err != nil {
        log.Error("redis ZRangeByScore err, uid=%v, appid=%v, msgid=%v, err=%v", uid, appid, msgid, err)
        return
    }

    if len(vals) == 0 {
        err = errors.New("not found")
        return
    }

    return vals[0], nil
}

func GetValsFromQueue(uid int64, appid int32, msgid int64) (vals []string, err error) {
    k := getMsgQueueKey(uid, appid)
    min := fmt.Sprintf("(%v", msgid)
    vals, err = gMRedisClient.ZRangeByScore(k, redis.ZRangeBy{Min: min, Max: "+inf"}).Result()
    if err != nil {
        log.Error("redis ZRangeByScore err, uid=%v, appid=%v, msgid=%v, err=%v", uid, appid, msgid, err)
        return
    }

    return
}

func GetMsgsFromQueue(uid int64, appid int32, msgid int64) (msgs []pb.StoreMessage, err error) {
    var vals []string

    vals, err = GetValsFromQueue(uid, appid, msgid)
    if err != nil {
        return
    }

    msgs = make([]pb.StoreMessage, 0)
    for _, val := range vals {
        msg := pb.StoreMessage{}
        err = protobuf.Unmarshal([]byte(val), &msg)
        if err != nil {
            log.Error("uid=%v, appid=%v, msgid=%v, pb Unmarshal failed, err=%v", uid, appid, msgid, err)
            return
        }
        msgs = append(msgs, msg)
    }
    return
}

func GetMsgFromQueue(uid int64, appid int32, msgid int64) (msg pb.StoreMessage, err error) {
    var val string

    val, err = GetValFromQueue(uid, appid, msgid)
    if err != nil {
        return
    }

    err = protobuf.Unmarshal([]byte(val), &msg)
    if err != nil {
        log.Error("uid=%v, appid=%v, msgid=%v, pb Unmarshal failed, err=%v", uid, appid, msgid, err)
        return
    }

    return
}

func UpdateUserLastAckMsg(uid int64, appid int32, msgid int64) (err error) {
    k := getUserInfoKey(uid, appid)
    _, err = gMRedisClient.HSet(k, LAST_ACK_MSG_KEY, msgid).Result()
    if err != nil {
        log.Error("redis hset lastAck err, uid=%v, appid=%v, msgid=%d, err=%v", uid, appid, msgid, err)
        return
    }
    return
}

func UpdateUserLastMsg(uid int64, appid int32, msgid int64) (err error) {
    k := getUserInfoKey(uid, appid)
    _, err = gMRedisClient.HSet(k, LAST_MSG_KEY, msgid).Result()
    if err != nil {
        log.Error("redis hset lastMsg err, uid=%v, appid=%v, msgid=%d, err=%v", uid, appid, msgid, err)
        return
    }
    return
}

func UpdateUserVersion(uid int64, appid int32, ver string) (err error) {
    k := getUserInfoKey(uid, appid)
    log.Error("uid=%v, appid=%v, ver=%v, k=%v", uid, appid, ver, k)
    _, err = gMRedisClient.HSet(k, VERSION_KEY, ver).Result()
    if err != nil {
        log.Error("redis hset version err, uid=%v, appid=%v, ver=%v, err=%v", uid, appid, ver, err)
        return
    }
    return
}

func GetUserInfo(uid int64, appid int32) (userInfo UserInfo, err error) {
    k := getUserInfoKey(uid, appid)
    u, err := gMRedisClient.HGetAll(k).Result()
    if err != nil {
        log.Error("redis get user info err, uid=%v, appid=%v, err=%v", uid, appid, err)
        return
    }
    userInfo.Ver = u[VERSION_KEY]
    if u[LAST_ACK_MSG_KEY] != "" {
        if userInfo.LastAckMsg, err = strconv.ParseInt(u[LAST_ACK_MSG_KEY], 10, 64); err != nil {
            log.Error("uid=%v, appid=%v, lastAck[%v]  parse err error(%s)", u[LAST_ACK_MSG_KEY], uid, appid, err)
            return
        }
    }
    if u[LAST_MSG_KEY] != "" {
        if userInfo.LastMsg, err = strconv.ParseInt(u[LAST_MSG_KEY], 10, 64); err != nil {
            log.Error("uid=%v, appid=%v, lastMsg[%v]  parse err error(%s)", u[LAST_MSG_KEY], uid, appid, err)
            return
        }
    }

    return
}
