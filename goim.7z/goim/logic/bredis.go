package main

import (
    //"fmt"
    "github.com/go-redis/redis"
    log "github.com/thinkboy/log4go"
    "strconv"
    "time"
)

var (
    gBRedisClient *redis.Client //保存bssid对应的tv信息
)

func InitBRedis() {
    gBRedisClient = redis.NewClient(&redis.Options{
        Addr:     Conf.BRedisAddr,
        Password: Conf.BRedisPwd,
        DB:       Conf.BRedisDB,
        PoolSize: Conf.BRedisPool,

        IdleTimeout: 1 * time.Minute,
    })

    if _, err := gBRedisClient.Ping().Result(); err != nil {
        panic(err)
    }
}

func getBssidKey(bssid string, clientIp string) string {
    rediskey := "bss-" + bssid + "-" + clientIp
    return rediskey
}

func AddBssidTv(bssid string, clientIp string, tv int64) (err error) {
    rediskey := getBssidKey(bssid, clientIp)
    now := time.Now().Unix()
    tvStr := strconv.FormatInt(tv, 10)

    _, err = gBRedisClient.HSet(rediskey, tvStr, now).Result()
    if err != nil {
        log.Error("redis HSet err, bssid=%d, clientIp=%s, tv=%v, err=%s",
            bssid, clientIp, tv, err.Error())
        return
    }
    gBRedisClient.Expire(rediskey, time.Hour*24*3)

    return
}

func DelBssidTv(bssid string, clientIp string, tv int64) (err error) {
    rediskey := getBssidKey(bssid, clientIp)

    tvStr := strconv.FormatInt(tv, 10)

    _, err = gBRedisClient.HDel(rediskey, tvStr).Result()
    if err != nil {
        log.Error("redis HDel err, bssid=%d, clientIp=%s, tv=%v, err=%s",
            bssid, clientIp, tv, err.Error())
        return
    }

    return
}

func GetBssidTv(bssid string, clientIp string) (tvs map[string]string, err error) {
    rediskey := getBssidKey(bssid, clientIp)

    tvs, err = gBRedisClient.HGetAll(rediskey).Result()
    if err != nil {
        log.Error("redis get bssid  tv err, bssid=%s, clientIp=%s, err = %s \n",
            bssid, clientIp, err.Error())
        return
    }
    log.Info("bssid=%s, clientIp=%s ,tvs=%+v", bssid, clientIp, tvs)
    return
}
