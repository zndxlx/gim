package main

import (
    //"fmt"
    "time"

    "github.com/bluele/gcache"
    log "github.com/thinkboy/log4go"
)

const (
    syncInterval       = time.Duration(60*5) * time.Second
    channelCacheMax    = 10000
    channelCacheExpire = time.Duration(10*24*3600) * time.Second
)

type ChannelInfo struct {
    Id     int32
    Tid    int32
    Secret string
    Md5Key string
    tType  int32
}

var (
    channelCache gcache.Cache
)

func GetChannelInfo(id int32) (info ChannelInfo, err error) {
    var value interface{}
    value, err = channelCache.Get(id)
    if err != nil {
        log.Error("get %d failed, error(%v)", id, err)
        return
    }

    var ok bool
    info, ok = value.(ChannelInfo)
    if !ok {
        log.Error("value type error")
        return
    }

    log.Debug("ChannelInfo=%+v", info)

    return
}

func getAllChannelInfo() (channels []ChannelInfo, err error) {
    rows, err := gYunDb.Query(`SELECT id,tid,secret,md5_key,terminal_type FROM tb_channel`)
    if err != nil {
        log.Error("query failed, err = %s \n", err.Error())
        return
    }

    defer rows.Close()
    for rows.Next() {
        var info ChannelInfo
        err = rows.Scan(&info.Id, &info.Tid, &info.Secret, &info.Md5Key, &info.tType)
        if err != nil {
            log.Error("err=%v", err)
            return
        }
        //log.Debug("ChannelInfo=%+v", info)
        channels = append(channels, info)
    }
    err = rows.Err()
    if err != nil {
        log.Error("query failed, err = %s \n", err.Error())
        return
    }
    return
}

func getUpdateChannelInfo() (channels []ChannelInfo, err error) {
    rows, err := gYunDb.Query(`SELECT id,tid,secret,md5_key,terminal_type FROM tb_channel
        where UNIX_TIMESTAMP(last_time)>= UNIX_TIMESTAMP()-660
        and UNIX_TIMESTAMP(last_time) <= UNIX_TIMESTAMP()`)
    if err != nil {
        log.Error("query failed, err = %s \n", err.Error())
        return
    }

    defer rows.Close()
    for rows.Next() {
        var info ChannelInfo
        err = rows.Scan(&info.Id, &info.Tid, &info.Secret, &info.Md5Key, &info.tType)
        if err != nil {
            log.Error("err=%v", err)
            return
        }
        log.Debug("ChannelInfo=%+v", info)
        channels = append(channels, info)
    }
    err = rows.Err()
    if err != nil {
        log.Error("query failed, err = %s \n", err.Error())
        return
    }
    return
}

func syncUpdateChanel() {
    channels, err := getUpdateChannelInfo()
    if err != nil {
        return
    }

    for _, channel := range channels {
        channelCache.Set(channel.Id, channel)
    }
}

func syncAllChanel() {
    channels, err := getAllChannelInfo()
    if err != nil {
        return
    }

    for _, channel := range channels {
        channelCache.Set(channel.Id, channel)
    }
    return
}

func syncAllTask() {
    c := time.Tick(channelCacheExpire / 2)
    for _ = range c {
        go syncAllChanel()
    }
}

func syncUpdateTask() {
    c := time.Tick(syncInterval)
    for _ = range c {
        go syncUpdateChanel()
    }
}

func InitChannelCache() {
    channelCache = gcache.New(channelCacheMax).LRU().
        Expiration(channelCacheExpire).
        Build()

    syncAllChanel()
    go syncUpdateTask()
    go syncAllTask()
}
