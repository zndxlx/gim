package main

import (
    "fmt"
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
    log "github.com/thinkboy/log4go"
    "net/http"
)

var (
    LogicAuthCount = prometheus.NewCounterVec(
        prometheus.CounterOpts{
            Name: "logic_auth_count",
            Help: "logic auth count",
        },
        []string{"appid"},
    )
    LogicErrTokenCount = prometheus.NewCounterVec(
        prometheus.CounterOpts{
            Name: "logic_auth_err_token_count",
            Help: "logic auth err token count",
        },
        []string{"appid"},
    )
)

type Monitor struct {
}

// StartPprof start http monitor.
func InitMonitor(binds []string) {
    m := new(Monitor)
    monitorServeMux := http.NewServeMux()
    monitorServeMux.HandleFunc("/monitor/ping", m.Ping)
    monitorServeMux.Handle("/metrics", promhttp.Handler())
    for _, addr := range binds {
        go func(bind string) {
            if err := http.ListenAndServe(bind, monitorServeMux); err != nil {
                log.Error("http.ListenAndServe(\"%s\", pprofServeMux) error(%v)", addr, err)
                panic(err)
            }
        }(addr)
    }
    prometheus.MustRegister(LogicAuthCount)
    prometheus.MustRegister(LogicErrTokenCount)
}

// monitor ping
func (m *Monitor) Ping(w http.ResponseWriter, r *http.Request) {
    for _, c := range routerServiceMap {
        if err := c.Available(); err != nil {
            http.Error(w, fmt.Sprintf("ping rpc error(%v)", err), http.StatusInternalServerError)
            return
        }
    }
    w.Write([]byte("ok"))
}
