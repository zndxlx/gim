package main

const (
    OK          = 1
    ReqParaErr  = 400
    InternalErr = 65535
)
