package main

import (
    "encoding/json"
    "errors"
    "fmt"
    log "github.com/thinkboy/log4go"
    inet "goim/libs/net"
    "goim/libs/pb"
    "goim/libs/proto"
    "net"
    "net/rpc"
    "net/url"
    "sort"
    "strconv"
)

//设备上报的cap信息结构
type DataInfo struct {
    Bssid string `json:"bssid"` //bssid
    Name  string `json:"name"`  //设备名称
    Ver   string `json:"ver"`   //版本号
}

func InitRPC(auther Auther) (err error) {
    var (
        network, addr string
        c             = &RPC{auther: auther}
    )
    rpc.Register(c)
    for i := 0; i < len(Conf.RPCAddrs); i++ {
        log.Info("start listen rpc addr: \"%s\"", Conf.RPCAddrs[i])
        if network, addr, err = inet.ParseNetwork(Conf.RPCAddrs[i]); err != nil {
            log.Error("inet.ParseNetwork() error(%v)", err)
            return
        }
        go rpcListen(network, addr)
    }
    return
}

func rpcListen(network, addr string) {
    l, err := net.Listen(network, addr)
    if err != nil {
        log.Error("net.Listen(\"%s\", \"%s\") error(%v)", network, addr, err)
        panic(err)
    }
    // if process exit, then close the rpc bind
    defer func() {
        log.Info("rpc addr: \"%s\" close", addr)
        if err := l.Close(); err != nil {
            log.Error("listener.Close() error(%v)", err)
        }
    }()
    rpc.Accept(l)
}

// RPC
type RPC struct {
    auther Auther
}

func (r *RPC) Ping(arg *proto.NoArg, reply *proto.NoReply) error {
    return nil
}

// Connect auth and registe login
func (r *RPC) Connect(arg *proto.ConnArg, reply *proto.ConnReply) (err error) {
    if arg == nil {
        err = ErrConnectArgs
        log.Error("Connect() error(%v)", err)
        return
    }
    var (
        uid  int64
        seq  int32
        data string
    )

    if uid, reply.RoomId, data, err = r.auther.Auth(arg.Token); err != nil {
        return
    }

    if seq, err = connect(uid, arg.Server, reply.RoomId, arg.ClientIp, data); err == nil {
        reply.Key = encode(uid, seq)

        if len(data) > 2 {
            var dataInfo DataInfo
            if tmpErr := json.Unmarshal([]byte(data), &dataInfo); tmpErr != nil {
                log.Info("json.Unmarshal failed, data=%s, tmpErr=%v", data, tmpErr)
                return
            }
            if dataInfo.Ver >= "2.0" { //2.0版本上才支持离线
                userInfo, tmpErr := GetUserInfo(uid, reply.RoomId)
                if tmpErr == nil {
                    reply.LastAckMsgID = userInfo.LastAckMsg
                    reply.LastMsgID = userInfo.LastMsg
                }
                log.Info("userInfo=%+v, reply=%+v, tmpErr=%v", userInfo, reply, tmpErr)
                if userInfo.Ver != dataInfo.Ver {
                    UpdateUserVersion(uid, reply.RoomId, dataInfo.Ver)
                }
            }
            connBredisProc(uid, reply.RoomId, &dataInfo, arg.ClientIp)
        }
    }
    return
}

func (r *RPC) Update(arg *proto.ConnArg, reply *proto.ConnReply) (err error) {
    if arg == nil {
        err = ErrConnectArgs
        log.Error("Connect() error(%v)", err)
        return
    }
    var (
        uid  int64
        data string
    )
    uid, reply.RoomId, data, _ = r.auther.Auth(arg.Token)
    err = update(uid, arg.Server, reply.RoomId, arg.ClientIp, data)
    return
}

// Disconnect notice router offline
func (r *RPC) Disconnect(arg *proto.DisconnArg, reply *proto.DisconnReply) (err error) {
    if arg == nil {
        err = ErrDisconnectArgs
        log.Error("Disconnect() error(%v)", err)
        return
    }
    var (
        uid int64
        seq int32
    )
    if uid, seq, err = decode(arg.Key); err != nil {
        log.Error("decode(\"%s\") error(%s)", arg.Key, err)
        return
    }
    disconnBredisProc(uid)
    reply.Has, err = disconnect(uid, seq, arg.RoomId)

    return
}

func (r *RPC) SyncMsg(arg *proto.SyncMsgReq, reply *proto.SyncMsgRsp) (err error) {
    if arg == nil {
        err = ErrSyncMsgArgs
        log.Error("SyncMsg() error(%v)", err)
        return
    }
    var (
        uid    int64
        msgid  int64
        pbMsgs []pb.StoreMessage
    )
    if uid, _, err = decode(arg.Key); err != nil {
        log.Error("arg=%v, decode key (\"%s\") error(%s)", *arg, arg.Key, err)
        return
    }

    if msgid, err = strconv.ParseInt(arg.MsgID, 10, 64); err != nil {
        log.Error("arg=%v, parse msgid (\"%s\") error(%s)", *arg, arg.MsgID, err)
        return
    }

    pbMsgs, err = GetMsgsFromQueue(uid, arg.Appid, msgid)
    if err != nil {
        return
    }

    reply.Msgs = make([]proto.Message, len(pbMsgs))
    for index, pbMsg := range pbMsgs {
        msg := proto.Message{}
        msg.MsgID = fmt.Sprintf("%v", pbMsg.MsgId)
        msg.SendTime = fmt.Sprintf("%v", pbMsg.SendTime)
        msg.MsgBody = pbMsg.MsgBody
        reply.Msgs[index] = msg
    }

    return
}

func (r *RPC) AckMsg(arg *proto.AckMsgReq, reply *proto.AckMsgRsp) (err error) {
    if arg == nil {
        err = ErrAckMsgArgs
        log.Error("AckMsg() error(%v)", err)
        return
    }
    var (
        uid       int64
        lastMsgid int64
    )
    if uid, _, err = decode(arg.Key); err != nil {
        log.Error("arg=%v, decode key (\"%s\") error(%s)", *arg, arg.Key, err)
        return
    }

    if len(arg.MsgIDs) == 0 {
        log.Error("arg=%v,have no msgid", *arg)
        err = errors.New("no msgid")
        return
    }

    sort.Strings(arg.MsgIDs)

    if lastMsgid, err = strconv.ParseInt(arg.MsgIDs[len(arg.MsgIDs)-1], 10, 64); err != nil {
        log.Error("arg=%v, parse msgid (\"%s\") error(%s)", *arg, arg.MsgIDs[len(arg.MsgIDs)-1], err)
        return
    }

    UpdateUserLastAckMsg(uid, arg.Appid, lastMsgid)

    go func() {
        for _, msgidStr := range arg.MsgIDs {
            msgid, tmpErr := strconv.ParseInt(msgidStr, 10, 64)
            if tmpErr != nil {
                log.Error("parse msgid (\"%s\") error(%s)", msgidStr, err)
                continue
            }

            pbMsg, tmpErr := GetMsgFromQueue(uid, arg.Appid, msgid)
            if tmpErr != nil {
                log.Error("GetMsgFromQueue failed, uid=%v, Appid=%v, msgid=%v, error(%s)", uid, arg.Appid, msgid, err)
                continue
            }
            log.Info("uid=%v, appid=%v, msgid=%d, pbmsg=%+v", uid, arg.Appid, msgid, pbMsg.String())
            //TODO 根据ackop回调通知
        }
    }()

    return
}

//增加bssid对应tv列表处理
func connBredisProc(uid int64, appid int32, dataInfo *DataInfo, clientIp string) {
    if dataInfo == nil {
        log.Error("dataInfo == nil")
        return
    }

    channel, tmpErr := GetChannelInfo(appid)
    if tmpErr != nil {
        log.Error("get channel info failed, err %v", tmpErr)
        return
    }
    log.Info("uid=%d, appid=%d, dataInfo=%v, clientIp=%s, tType=%d", uid, appid, *dataInfo, clientIp, channel.tType)
    if channel.tType != 2 { //2表示接收端
        return
    }
    if len(dataInfo.Bssid) > 0 {
        bssid, err := url.QueryUnescape(dataInfo.Bssid)
        if err != nil {
            log.Error("QueryUnescape failed, dataInfo.Bssid=%s, err=%v", dataInfo.Bssid, err)
            return
        }
        host, _, err := net.SplitHostPort(clientIp)
        if err != nil {
            log.Error("SplitHostPort failed, err=%v", err)
            return
        }

        AddBssidTv(bssid, host, uid)
    } else {
        log.Info("no  bssid")
    }

}

//删除redis中bssid-clientip键保存的该uid的信息
func disconnBredisProc(uid int64) {
    clientInfo, err := getClientInfo(uid)
    if err != nil {
        log.Error("Get clientinfo(\"%d\") error(%v)", uid, err)
        return
    }
    if clientInfo == nil {
        return
    }
    channel, tmpErr := GetChannelInfo(clientInfo.AppId)
    if tmpErr != nil {
        log.Error("get channel info failed, err %v", tmpErr)
        return
    }
    if channel.tType != 2 { //2表示接收端
        return
    }
    var dataInfo DataInfo
    if tmpErr := json.Unmarshal([]byte(clientInfo.ClientData), &dataInfo); tmpErr != nil {
        log.Error("json.Unmarshal failed, data=%s, tmpErr=%v", clientInfo.ClientData, tmpErr)
        return
    }
    if len(dataInfo.Bssid) > 0 {
        bssid, err := url.QueryUnescape(dataInfo.Bssid)
        if err != nil {
            log.Error("QueryUnescape failed, dataInfo.Bssid=%s, err=%v", dataInfo.Bssid, err)
            return
        }

        host, _, err := net.SplitHostPort(clientInfo.Ip)
        if err != nil {
            log.Error("SplitHostPort failed, err=%v", err)
            return
        }

        DelBssidTv(bssid, host, uid)
    } else {
        log.Info("uid=%d, no  bssid", uid)
    }
    return
}
