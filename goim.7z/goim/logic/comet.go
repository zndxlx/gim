package main

import (
    //"encoding/json"
    //"goim/libs/define"
    inet "goim/libs/net"
    "goim/libs/net/xrpc"
    "goim/libs/proto"

    "strings"

    log "github.com/thinkboy/log4go"
)

var (
    cometServiceMap = make(map[int32]*Comet)
)

const (
    CometService              = "PushRPC"
    CometServicePing          = "PushRPC.Ping"
    CometServiceRooms         = "PushRPC.Rooms"
    CometServicePushMsg       = "PushRPC.PushMsg"
    CometServiceMPushMsg      = "PushRPC.MPushMsg"
    CometServiceBroadcast     = "PushRPC.Broadcast"
    CometServiceBroadcastRoom = "PushRPC.BroadcastRoom"
    CometServiceNotifyActive  = "PushRPC.NotifyActive"
    CometServiceNotifyMsg     = "PushRPC.NotifyMsg"
)

type Comet struct {
    serverId  int32
    rpcClient *xrpc.Clients
    address   string
}

func NotifyActive(serverId int32, keys []string) {
    var args = &proto.NotifyActiveArg{Keys: keys}
    var reply = &proto.NoReply{}
    if c, ok := cometServiceMap[serverId]; ok {
        err := c.rpcClient.Call(CometServiceNotifyActive, args, reply)
        if err != nil {
            log.Error("rpcClient.Call(%s, %v, reply) serverId:%d error(%v)",
                CometServiceNotifyActive, args, c.serverId, err)
        }
    } else {
        log.Error("comet server not found")
    }
}

func NotifyMsg(serverId int32, keys []string, msgid int64) {
    var args = &proto.NotifyMsgArg{Keys: keys, MsgID: msgid}
    var reply = &proto.NoReply{}
    if c, ok := cometServiceMap[serverId]; ok {
        err := c.rpcClient.Call(CometServiceNotifyMsg, args, reply)
        if err != nil {
            log.Error("rpcClient.Call(%s, %v, reply) serverId:%d error(%v)",
                CometServiceNotifyMsg, args, c.serverId, err)
        }
    } else {
        log.Error("comet server not found serverId=%v", serverId)
    }
}

func InitComet(addrs map[int32]string) (err error) {
    var (
        serverId      int32
        bind          string
        network, addr string
    )
    for serverId, bind = range addrs {
        if _, ok := cometServiceMap[serverId]; ok {
            continue
        }

        var rpcOptions []xrpc.ClientOptions
        for _, bind = range strings.Split(bind, ",") {
            if network, addr, err = inet.ParseNetwork(bind); err != nil {
                log.Error("inet.ParseNetwork() error(%v)", err)
                return
            }
            options := xrpc.ClientOptions{
                Proto: network,
                Addr:  addr,
            }
            rpcOptions = append(rpcOptions, options)
        }
        // rpc clients
        rpcClient := xrpc.Dials(rpcOptions)
        // ping & reconnect
        rpcClient.Ping(CometServicePing)
        // comet
        c := new(Comet)
        c.serverId = serverId
        c.rpcClient = rpcClient
        c.address = addr
        cometServiceMap[serverId] = c

        log.Info("init comet[%d], rpc: %v", serverId, rpcOptions)
    }
    return
}
