package main

import (
    "crypto/md5"
    "fmt"
    log "github.com/thinkboy/log4go"
    //"goim/libs/define"
    "errors"
    "strconv"
    "strings"
    "time"
)

const (
    // AuthExpireTime = 60 * 60 * 6 //6小时
    AuthExpireTime = 60 * 60 * 2400 //2400 小时
)

// developer could implement "Auth" interface for decide how get userId, or roomId
type Auther interface {
    Auth(token string) (userId int64, roomId int32, data string, err error)
}

type DefaultAuther struct {
}

func NewDefaultAuther() *DefaultAuther {
    return &DefaultAuther{}
}

func (a *DefaultAuther) Auth(token string) (userId int64, roomId int32, data string, err error) {
    var tmpErr error
    tks := strings.Split(token, ";")

    if len(tks) < 3 {
        log.Error("token %s, Split len < 3 ", token)
        err = ErrConnectToken
        return
    }

    if Conf.ForceToken != 0 && len(tks) < 4 {
        log.Error("token %s, Split len < 4 ", token)
        err = ErrConnectToken
        return
    }

    if userId, tmpErr = strconv.ParseInt(tks[0], 10, 64); tmpErr != nil {
        log.Error("token %s, auth failed, err %v", token, tmpErr)
        err = ErrConnectToken
        return
    }

    if tmpRoomId, tmpErr := strconv.Atoi(tks[2]); tmpErr != nil {
        log.Error("token %s, auth failed, err %v", token, tmpErr)
        err = ErrConnectToken
        return
    } else {
        roomId = int32(tmpRoomId)
    }

    LogicAuthCount.WithLabelValues(tks[2]).Inc()

    if len(tks) > 3 && tks[3] != "" {
        channel, tmpErr := GetChannelInfo(roomId)
        if tmpErr != nil {
            log.Error("token %s, auth failed, err %v", token, tmpErr)
            LogicErrTokenCount.WithLabelValues(tks[2]).Inc()
            err = ErrConnectToken
            return
        }

        if tmpErr := CheckToken(roomId, userId, channel.Md5Key, tks[3]); tmpErr != nil {
            log.Error("token %s, auth failed, err: %v", token, tmpErr)
            LogicErrTokenCount.WithLabelValues(tks[2]).Inc()
            err = ErrConnectToken
            return
        }
    }

    data = tks[1]

    return
}

func CreateToken(appid int32, uid int64, time int64, key string) (token string) {
    md5str := fmt.Sprintf("%d%d%d%s", uid, appid, time, key)
    md5value := md5.Sum([]byte(md5str))
    token = fmt.Sprintf("%x%d", md5value[4:12], time)

    log.Debug("appid=%d, uid=%d, time=%d, token=%s", appid,
        uid, time, token)

    return
}

func CheckToken(appid int32, uid int64, key string, token string) (err error) {
    if len(token) <= 16 {
        err = errors.New("token too short")
        return
    }

    tokenData := []byte(token)

    tokenTime, err := strconv.ParseInt(string(tokenData[16:]), 10, 0)
    if err != nil {
        log.Error("%s pares to int failed ", string(tokenData[16:]))
        return
    }

    if time.Now().Unix()-tokenTime > AuthExpireTime {
        log.Info("token time out now %d, token_time %d ", time.Now().Unix(), tokenTime)
        err = errors.New("token time out")
        return
    }

    needToken := CreateToken(appid, uid, tokenTime, key)
    if token != needToken {
        log.Error("token error %s, need %s", token, needToken)
        err = errors.New("token Invalid")
        return
    }

    return
}
