// Copyright © 2014 Terry Mao, LiuDing All rights reserved.
// This file is part of gopush-cluster.

// gopush-cluster is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// gopush-cluster is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with gopush-cluster.  If not, see <http://www.gnu.org/licenses/>.

package main

import (
    "flag"
    "fmt"
    "github.com/Terry-Mao/goconf"
    "os"
    "runtime"
    "strconv"
    // "strings"
    "errors"
    "github.com/shima-park/agollo"
    "time"
)

var (
    Conf     *Config
    confFile string
)

const (
    CommonCfgFile = "./common.conf"
    OwnCfgFile    = "./own.conf"
)

func init() {
    flag.StringVar(&confFile, "c", "./logic.conf", " set logic config file path")
}

type Config struct {
    //apollo 配置
    ApolloAddr      string `goconf:"apollo:addr"`
    ApolloAppid     string `goconf:"apollo:appid"`
    ApolloCluster   string `goconf:"apollo:cluster"`
    ApolloNameSpace string `goconf:"apollo:namespace"`
    ApolloRefresh   int    `goconf:"apollo:refresh"`

    // base section
    PidFile          string        `goconf:"base:pidfile"`
    Dir              string        `goconf:"base:dir"`
    Log              string        `goconf:"base:log"`
    MaxProc          int           `goconf:"base:maxproc"`
    PprofAddrs       []string      `goconf:"base:pprof.addrs:,"`
    RPCAddrs         []string      `goconf:"base:rpc.addrs:,"`
    HTTPAddrs        []string      `goconf:"base:http.addrs:,"`
    HTTPReadTimeout  time.Duration `goconf:"base:http.read.timeout:time"`
    HTTPWriteTimeout time.Duration `goconf:"base:http.write.timeout:time"`
    ForceToken       int           `goconf:"base:forcetoken"`
    ServerId         int32         `goconf:"base:server.id"`
    // router RPC
    RouterRPCAddrs map[string]string `-`
    // kafka
    KafkaAddrs []string `goconf:"kafka:addrs"`
    // monitor
    MonitorOpen  bool     `goconf:"monitor:open"`
    MonitorAddrs []string `goconf:"monitor:addrs:,"`
    // white
    WhiteOpen    bool     `goconf:"white:open"`
    WhiteIps     []string `goconf:"white:ips:,"`
    WhiteActions []int64  `goconf:"white:actions:,"`

    // yun db
    YunDbAddr     string `goconf:"yundb:addr"`
    YunDbUser     string `goconf:"yundb:user"`
    YunDbPass     string `goconf:"yundb:pass"`
    YunDbDataBase string `goconf:"yundb:database"`

    // comet
    Comets map[int32]string `goconf:"-"`

    // redis
    RedisSyncOpen bool   `goconf:"redis:sync.open"`
    SyncDelay     int    `goconf:"redis:sync.delay"`
    RedisAddrs    string `goconf:"redis:addrs"`
    RedisPwd      string `goconf:"redis:pwd"`
    RedisDB       int    `goconf:"redis:db"`

    //bssid-tv redis
    BRedisAddr string `goconf:"bredis:addr"`
    BRedisPwd  string `goconf:"bredis:pwd"`
    BRedisDB   int    `goconf:"bcredis:db"`
    BRedisPool int    `goconf:"bredis:pool"`

    //存储消息 redis
    MRedisAddr string `goconf:"mredis:addr"`
    MRedisPwd  string `goconf:"mredis:pwd"`
    MRedisDB   int    `goconf:"mredis:db"`
    MRedisPool int    `goconf:"mredis:pool"`
}

func NewConfig() *Config {
    return &Config{
        // base section
        Comets:         make(map[int32]string),
        PidFile:        "/tmp/goim-logic.pid",
        Dir:            "./",
        Log:            "./logic-log.xml",
        MaxProc:        runtime.NumCPU(),
        PprofAddrs:     []string{"localhost:6971"},
        HTTPAddrs:      []string{"7172"},
        RouterRPCAddrs: make(map[string]string),
        ForceToken:     0,
    }
}

// InitConfig init the global config.
func InitConfig() (err error) {
    Conf = NewConfig()
    localConf := goconf.New()
    if err = localConf.Parse(confFile); err != nil {
        return err
    }
    if err := localConf.Unmarshal(Conf); err != nil {
        return err
    }

    UpdateCfg()

    commonConf := goconf.New()
    if err = commonConf.Parse(CommonCfgFile); err != nil {
        return err
    }
    if err := commonConf.Unmarshal(Conf); err != nil {
        return err
    }

    for _, serverID := range commonConf.Get("router.addrs").Keys() {
        addr, err := commonConf.Get("router.addrs").String(serverID)
        if err != nil {
            return err
        }
        Conf.RouterRPCAddrs[serverID] = addr
    }

    var serverIDi int64
    for _, serverID := range commonConf.Get("comets").Keys() {
        addr, err := commonConf.Get("comets").String(serverID)
        if err != nil {
            return err
        }
        serverIDi, err = strconv.ParseInt(serverID, 10, 32)
        if err != nil {
            return err
        }
        Conf.Comets[int32(serverIDi)] = addr
    }

    ownConf := goconf.New()
    if err = ownConf.Parse(OwnCfgFile); err != nil {
        fmt.Printf("parse own cfg file failed %+v\n", err)
        return nil
    }
    if err := ownConf.Unmarshal(Conf); err != nil {
        fmt.Printf("Unmarshal own cfg file failed %+v\n", err)
        return nil
    }

    return nil
}

func ReloadConfig() (*Config, error) {
    fmt.Printf("not support reload config\n")
    return nil, errors.New("not support reload config")
}

func UpdateCfg() {
    a, err := agollo.New(Conf.ApolloAddr, Conf.ApolloAppid,
        agollo.Cluster(Conf.ApolloCluster),
        agollo.DefaultNamespace(Conf.ApolloNameSpace),
        agollo.PreloadNamespaces(Conf.ApolloNameSpace),
        agollo.AutoFetchOnCacheMiss(),
        agollo.FailTolerantOnBackupExists(),
        agollo.ConfigServerRefreshIntervalInSecond(time.Second*(time.Duration(Conf.ApolloRefresh))))
    if err != nil {
        fmt.Printf("StartApollo failed err = %+v", err)
    }

    // fmt.Printf("content=%+v\n", a.Get("content"))
    content := a.Get("content")
    if len(content) > 10 {
        f, err := os.OpenFile(CommonCfgFile, os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0600)
        if err != nil {
            fmt.Printf("open cfg file failed, err=%v\n", err)
        }
        defer f.Close()
        num, err := f.WriteString(content)
        if err != nil {
            fmt.Printf("write cfg file failed, num=%d, err=%v\n", num, err)
        }
    }

    return
}
