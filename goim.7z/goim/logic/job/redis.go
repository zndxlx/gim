package main

import (
    "strconv"
    "strings"
    "time"

    "github.com/go-redis/redis"
    log "github.com/thinkboy/log4go"
)

type RedisConfig struct {
    RedisAddr string
    RedisPwd  string
    RedisDB   int
    SyncDelay int
}

type CometInfo struct {
    ServerId   int32
    IP         string
    CPU        int64
    CPUUsed    int64
    Memory     int64
    MemoryUsed int64
    LastTime   string
    Timestamp  int64
}

func SyncComet(conf RedisConfig, options CometOptions) {
    if conf.RedisPwd == "null" {
        conf.RedisPwd = ""
    }
    for {
        addrs := getComet(conf)
        log.Debug("InitComet %v", addrs)
        InitComet(addrs, options)
        time.Sleep(time.Duration(conf.SyncDelay) * time.Second)
    }
}

func getComet(conf RedisConfig) (addrs map[int32]string) {
    client := redis.NewClient(&redis.Options{
        Addr:     conf.RedisAddr,
        Password: conf.RedisPwd, // no password set
        DB:       conf.RedisDB,  // use default DB
    })
    defer client.Close()
    _, err := client.Ping().Result()
    if err != nil {
        log.Error("Redis Connect Failed [add:%s]", conf.RedisAddr)
        return
    }
    addrs = make(map[int32]string)
    val, err := client.Keys("comet-*").Result()
    if err != nil {
        log.Error("Get fail", err)
    }
    log.Debug("cometaddrs:%s", val)
    for _, cometStr := range val {
        cometStrs := strings.Split(cometStr, ":")
        if len(cometStrs) < 2 {
            log.Error("==>Convert cometStr Failed", cometStr)
        } else {
            cometIp := cometStrs[1]
            cometIdStr := strings.Split(cometStrs[0], "-")[1]
            cometId64, err := strconv.ParseInt(cometIdStr, 10, 64)
            if err != nil {
                log.Error("==>Convert cometId Failed", cometStr)
            } else {
                cometId := int32(cometId64)
                if _, ok := addrs[cometId]; ok {
                    log.Error("Comet ServerId is exists [%d:%s,%s]", cometId, cometIp, addrs[cometId])
                }
                addrs[cometId] = "tcp@" + cometIp + ":8092"
            }
        }
    }
    return addrs
}
