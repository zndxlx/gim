package main

import (
    "database/sql"
    "flag"
    "fmt"
    "github.com/bwmarrin/snowflake"
    _ "github.com/go-sql-driver/mysql"
    log "github.com/thinkboy/log4go"
    "goim/libs/perf"
    "runtime"
)

var (
    gYunDb    *sql.DB
    gSnowNode *snowflake.Node
)

func initDb() {
    var err error

    yunDbName := fmt.Sprintf(`%s:%s@tcp(%s)/%s?charset=utf8&parseTime=true`,
        Conf.YunDbUser, Conf.YunDbPass, Conf.YunDbAddr, Conf.YunDbDataBase)
    gYunDb, err = sql.Open("mysql", yunDbName)
    if err != nil {
        panic(err)
    }
    gYunDb.SetMaxIdleConns(-1)
    gYunDb.SetMaxOpenConns(5)
}

func initSnowNode(serverid int64) {
    var err error
    gSnowNode, err = snowflake.NewNode(serverid)
    if err != nil {
        panic("err")
    }
    return
}

func main() {
    flag.Parse()
    if err := InitConfig(); err != nil {
        panic(err)
    }
    runtime.GOMAXPROCS(Conf.MaxProc)
    log.LoadConfiguration(Conf.Log)
    defer log.Close()
    log.Info("logic[%s] start, conf=%+v", Ver, Conf)
    initSnowNode(int64(Conf.ServerId))
    initDb()
    InitBRedis()
    InitMRedis()
    perf.Init(Conf.PprofAddrs)
    // router rpc
    if err := InitRouter(Conf.RouterRPCAddrs); err != nil {
        log.Warn("router rpc current can't connect, retry")
    }
    // start monitor
    if Conf.MonitorOpen {
        InitMonitor(Conf.MonitorAddrs)
    }
    MergeCount()
    go SyncCount()

    InitChannelCache()

    // logic rpc
    if err := InitRPC(NewDefaultAuther()); err != nil {
        panic(err)
    }
    if err := InitHTTP(); err != nil {
        panic(err)
    }
    if err := InitKafka(Conf.KafkaAddrs); err != nil {
        panic(err)
    }

    err := InitComet(Conf.Comets)
    if Conf.RedisSyncOpen {
        redisConfig := RedisConfig{
            RedisAddr: Conf.RedisAddrs,
            RedisPwd:  Conf.RedisPwd,
            RedisDB:   Conf.RedisDB,
            SyncDelay: Conf.SyncDelay,
        }
        go SyncComet(redisConfig)
    }
    if err != nil {
        log.Warn("comet rpc current can't connect, retry")
    }

    // block until a signal is received.
    InitSignal()
}
