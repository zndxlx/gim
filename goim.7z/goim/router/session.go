package main

import (
    "goim/libs/define"
    "goim/libs/proto"
)

type Session struct {
    seq     int32
    servers map[int32]int32           // seq:server
    roomids map[int32]int32           // seq:roomid
    rooms   map[int32]map[int32]int32 // roomid:seq:server with specified room id
    info    *proto.ClientInfo
}

// NewSession new a session struct. store the seq and serverid.
func NewSession(server int, ip string, data string) *Session {
    s := new(Session)
    s.servers = make(map[int32]int32, server)
    s.roomids = make(map[int32]int32, server)
    s.rooms = make(map[int32]map[int32]int32)
    s.seq = 0
    s.info = &proto.ClientInfo{
        Ip:         ip,
        ClientData: data,
        Status:     true,
    }
    return s
}

func (s *Session) nextSeq() int32 {
    s.seq++
    return s.seq
}

// PutRoom put a session in a room according with subkey.
func (s *Session) Put(server int32, roomId int32) (seq int32) {
    var (
        ok   bool
        room map[int32]int32
    )
    seq = s.nextSeq()
    s.servers[seq] = server
    s.roomids[seq] = roomId
    if roomId != define.NoRoom {
        if room, ok = s.rooms[roomId]; !ok {
            room = make(map[int32]int32)
            s.rooms[roomId] = room
        }
        room[seq] = server
    }
    return
}

func (s *Session) Servers() (seqs []int32, servers []int32) {
    var (
        i           = len(s.servers)
        seq, server int32
    )
    seqs = make([]int32, i)
    servers = make([]int32, i)
    for seq, server = range s.servers {
        i--
        seqs[i] = seq
        servers[i] = server
    }
    return
}

func (s *Session) ServersWithAppid(appid int32) (seqs []int32, servers []int32) {
    seqs = []int32{}
    servers = []int32{}
    for seq, server := range s.servers {
        if s.roomids[seq] == appid {
            seqs = append(seqs, seq)
            servers = append(servers, server)
        }
    }

    return
}

func (s *Session) Clientinfo() (clientInfo *proto.ClientInfo) {
    clientInfo = s.info
    return
}

// Del delete the session and room by subkey.
func (s *Session) Del(seq int32) (has, empty bool, server int32) {
    var (
        ok     bool
        room   map[int32]int32
        roomId = int32(define.NoRoom)
    )

    if server, has = s.servers[seq]; has {
        roomId = s.roomids[seq]
        delete(s.servers, seq)
        delete(s.roomids, seq)
    }
    empty = (len(s.servers) == 0)
    if empty {
        s.info.Status = false
    }

    if room, ok = s.rooms[roomId]; ok {
        delete(room, seq)
        if len(room) == 0 {
            delete(s.rooms, roomId)
        }
    }
    return
}

func (s *Session) Count() int {
    return len(s.servers)
}
